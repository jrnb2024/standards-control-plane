"""WebhookNotifier + EmailNotifier for WP-SCC-2 CT endpoint resolver.

These live in their own module because they bring in validation logic
(URL validation with same-origin + admin-path denylist, SMTP metacharacter
rejection) that's complex enough to keep separate from the resolver core.
"""

from __future__ import annotations

import asyncio
import ipaddress
import logging
import os
import posixpath
import re
import smtplib
from email.message import EmailMessage
from typing import Any, Awaitable, Callable, Iterable
from urllib.parse import unquote, urlparse

import httpx

from ct_auth.bff import (
    _is_dev_env,
    _reject_url_control_characters,
    _resolve_hostname_is_private,
    _METADATA_DENYLIST_HOSTS,
)
from ct_auth.resolver import FailoverEvent, Notifier

_logger = logging.getLogger("ct_auth.resolver")


def _build_notifier_from_env(
    *,
    primary_url: str,
    fallback_url: str,
) -> "Notifier | None":
    """Bootstrap a :class:`CompositeNotifier` from env vars (A-006 / AC-2.30).

    Reads ``CT_FALLBACK_NOTIFY_EMAIL`` and ``CT_FALLBACK_NOTIFY_WEBHOOK``.
    Returns None when neither is set (caller falls back to NoopNotifier).
    Aggregates whatever is present into a single ``CompositeNotifier``.

    This is the one place where env-var wiring lives; the rest of the code
    treats notifiers as injected dependencies.
    """
    # Lazy imports so that ct_auth.notifiers can be imported from ct_auth.resolver
    # without triggering a cycle at module top.
    from ct_auth.resolver import CompositeNotifier

    email_raw = os.environ.get("CT_FALLBACK_NOTIFY_EMAIL", "").strip()
    webhook_raw = os.environ.get("CT_FALLBACK_NOTIFY_WEBHOOK", "").strip()

    notifiers: list[Notifier] = []
    if email_raw:
        recipients = [r.strip() for r in email_raw.split(",") if r.strip()]
        if recipients:
            try:
                notifiers.append(EmailNotifier(recipients=recipients))
            except ValueError as exc:
                # B-030: re-raise with env-var context so operators can
                # trace a cryptic regex failure back to the env-file entry.
                raise ValueError(
                    f"CT_FALLBACK_NOTIFY_EMAIL={email_raw!r} is invalid: {exc}"
                ) from exc
    if webhook_raw:
        try:
            notifiers.append(
                WebhookNotifier(
                    url=webhook_raw,
                    primary_url=primary_url,
                    fallback_url=fallback_url,
                )
            )
        except ValueError as exc:
            raise ValueError(
                f"CT_FALLBACK_NOTIFY_WEBHOOK={webhook_raw!r} is invalid: {exc}"
            ) from exc
    if not notifiers:
        return None
    return CompositeNotifier(notifiers)

# ---------------------------------------------------------------------------
# Shared URL validation
# ---------------------------------------------------------------------------

_ADMIN_PATH_DENYLIST = {
    "admin",
    "reset",
    "kill",
    "shutdown",
    ".env",
    "debug",
    "internal",
    "ops",
    "metrics",
}


def _validate_webhook_url(
    url: str,
    *,
    primary_url: str | None = None,
    fallback_url: str | None = None,
) -> None:
    """Validate a webhook URL against SSRF + same-origin + admin-path rules.

    Raises:
        ValueError: If the URL fails any check (B-001..B-004, B2-002, A3-005, N3-002).
    """
    _reject_url_control_characters(url, "webhook URL")
    parsed = urlparse(url)
    is_dev = _is_dev_env()

    # Reject userinfo (B-019)
    if parsed.username or parsed.password:
        raise ValueError(f"webhook URL must not carry userinfo: {url!r}")

    # Scheme
    if parsed.scheme not in ("http", "https"):
        raise ValueError(f"webhook URL must be http(s): got {parsed.scheme!r}")
    if parsed.scheme != "https" and not is_dev:
        raise ValueError("webhook URL must use https:// in non-development environments")

    hostname_raw = (parsed.hostname or "").strip("[]")
    # B-004: strip trailing dot before any comparison — `example.com.` and
    # `example.com` are semantically identical for DNS/HTTP.
    hostname = hostname_raw.rstrip(".").casefold()

    # Metadata always denied.
    if hostname in _METADATA_DENYLIST_HOSTS:
        raise ValueError(
            f"webhook URL hostname is a cloud-metadata address (always denied): {hostname!r}"
        )

    # SSRF: reject private IPs in non-dev.
    if not is_dev and hostname:
        try:
            addr = ipaddress.ip_address(hostname)
            if addr.is_private or addr.is_loopback or addr.is_link_local:
                raise ValueError(
                    "webhook URL must not resolve to a private/link-local/loopback address in non-dev"
                )
        except ValueError as e:
            if "private" in str(e) or "link-local" in str(e) or "loopback" in str(e):
                raise
            # Hostname (not literal IP) — DNS check for private resolution (B-002).
            # B-041 / A-502: pass the caller's is_dev snapshot so the helper
            # doesn't re-read ENV (TOCTOU closure).
            if _resolve_hostname_is_private(hostname, is_dev=is_dev):
                raise ValueError(
                    f"webhook hostname {hostname!r} resolves to a private/loopback "
                    "address; rejected in non-dev"
                )

    # Same-origin rejection (B2-002). Case-folded + trailing-dot-stripped.
    for other_url, label in ((primary_url, "primary_url"), (fallback_url, "fallback_url")):
        if not other_url:
            continue
        other_host_raw = (urlparse(other_url).hostname or "")
        other_host = other_host_raw.rstrip(".").casefold()
        if other_host and hostname == other_host:
            raise ValueError(
                f"webhook URL must not share hostname with {label}={other_url!r} "
                "(prevents exfiltration loops and SSRF against CT's own endpoints)"
            )

    # Admin-path denylist chain. Design, after Round 4 feedback (B-037):
    #
    # 1. Percent-decode to fixpoint (bounded) so `%2561dmin` → `%61dmin` →
    #    `admin`. Any residual `%` in the post-decode form is suspicious and
    #    suggests the operator is trying to smuggle something through
    #    (A-306 + B-021 balance).
    # 2. NFKC-normalise so fullwidth Unicode lookalikes (`ａdmin`, `Ａdmin`,
    #    fullwidth slash `／`) collapse to ASCII (B-034).
    # 3. **Strip Unicode category Mn/Mc/Me (combining marks) and Cf (format
    #    / invisible) characters**. B-037: NFKC alone does not handle
    #    zero-width joiners, soft hyphen, BOM, or combining diacritics.
    #    After stripping, `a\u0300dmin` → `admin`, `a\u200bdmin` → `admin`,
    #    `\ufeffadmin` → `admin`, etc.
    # 4. Case-fold + compare against denylist. Any denylisted segment → raise.
    import unicodedata as _unicodedata

    raw_path = parsed.path or "/"
    decoded = raw_path
    for _ in range(6):
        next_decoded = unquote(decoded)
        if next_decoded == decoded:
            break
        decoded = next_decoded
    # Windows-style backslash → forward slash
    decoded = decoded.replace("\\", "/")
    # A residual `%` after the fixpoint is a sign of an evasion attempt
    # (e.g. `%admin` where `%ad` happens to decode to a non-ASCII char).
    if "%" in decoded:
        raise ValueError(
            f"webhook URL path still contains a `%` after {6} decode iterations: "
            f"{decoded!r}. Use an unencoded path like /hook or /ct-flip."
        )
    normalised = posixpath.normpath(decoded)
    # NFKD-normalise BEFORE splitting so BOTH fullwidth `／` (U+FF0F) AND
    # precomposed accented characters (`à` → `a + U+0300`) decompose into
    # their ASCII base + combining marks, which we then strip. NFKC alone
    # was wrong because it RECOMPOSES `a + U+0300` back into `à` (category
    # `Ll`), bypassing the combining-mark strip. NFKD decomposition keeps
    # the combining mark separate so _strip_invisibles can remove it.
    normalised_nfkd = _unicodedata.normalize("NFKD", normalised)

    def _strip_invisibles(s: str) -> str:
        """Strip combining marks + format/invisible characters (B-037).

        Removes any char whose Unicode category starts with ``M`` (Mn,
        Mc, Me = combining marks) or is ``Cf`` (format / control
        formatting / invisible). Covers:
        - Zero-width joiner/non-joiner (U+200C, U+200D)
        - Zero-width space (U+200B)
        - Soft hyphen (U+00AD)
        - Byte-order mark (U+FEFF)
        - Combining diacriticals (U+0300..U+036F etc.)
        - Mongolian vowel separator (U+180E)
        """
        return "".join(
            ch for ch in s if not (
                _unicodedata.category(ch).startswith("M")
                or _unicodedata.category(ch) == "Cf"
            )
        )

    segments = [
        _strip_invisibles(_unicodedata.normalize("NFKD", s)).casefold()
        for s in normalised_nfkd.split("/")
        if s
    ]
    for seg in segments:
        if seg in _ADMIN_PATH_DENYLIST:
            raise ValueError(
                f"webhook URL path segment {seg!r} is denylisted (admin-path protection). "
                f"Decoded + NFKD + strip-invisibles path: {normalised_nfkd!r}"
            )


# ---------------------------------------------------------------------------
# Email address validation (B2-005)
# ---------------------------------------------------------------------------

# B-026: conservative RFC-5322 subset. Rejects quoted-local-part,
# bracketed-IP local-part (`admin@[192.168.1.1]`), and 1-letter TLDs.
# Operators whose MX uses any of those patterns should set
# CT_EMAIL_BACKEND=console (the error message points them there).
_EMAIL_REGEX = re.compile(r"\A[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}\Z")
_EMAIL_FORBIDDEN_CHARS = set("\r\n\0;<>")


def _validate_email_recipients(recipients: Iterable[str]) -> list[str]:
    cleaned: list[str] = []
    for raw in recipients:
        entry = raw.strip()
        if not entry:
            raise ValueError("email recipient entry is empty")
        if any(ch in entry for ch in _EMAIL_FORBIDDEN_CHARS):
            raise ValueError(
                f"email recipient contains forbidden control/metacharacter: {entry!r} (B2-005)"
            )
        if entry.count("@") != 1:
            raise ValueError(f"email recipient must contain exactly one '@': {entry!r}")
        if not _EMAIL_REGEX.fullmatch(entry):
            raise ValueError(
                f"email recipient fails conservative RFC-5322 regex: {entry!r} "
                "(set CT_EMAIL_BACKEND=console to bypass SMTP delivery entirely "
                "if your MX uses a pattern outside the subset)"
            )
        cleaned.append(entry)
    if not cleaned:
        raise ValueError("email recipients list is empty")
    return cleaned


# ---------------------------------------------------------------------------
# WebhookNotifier
# ---------------------------------------------------------------------------


class WebhookNotifier(Notifier):
    """POST a strict, allowlisted payload to a webhook URL on failover events.

    - SSRF + scheme + private-IP validation at construction (AC-2.5, B-002/003).
    - Same-origin rejection vs primary/fallback (B2-002).
    - Admin-path denylist with case-folded path-segment matching AFTER
      percent-decoding (A3-005, B-003).
    - Payload limited to the exact D-015 allowlist (AC-2.16, test 17).
    - Exponential backoff: 1s, 2s, 4s; 4xx/3xx not retried (test 9, 10, 25).
    - Outer wall-clock timeout of 10s on the whole notify() call (C-007).
    - follow_redirects=False so a 302 Location header is not followed (test 25).
    """

    # \A..\Z so trailing newlines cannot sneak past the regex (B-001).
    _APP_ID_REGEX = re.compile(r"\A[a-z0-9][a-z0-9._-]{0,63}\Z")

    def __init__(
        self,
        url: str,
        *,
        primary_url: str | None = None,
        fallback_url: str | None = None,
        app_id: str | None = None,
        _client: Any = None,
        _sleep: Callable[[float], Awaitable[None]] | None = None,
        overall_timeout_seconds: float = 10.0,
    ) -> None:
        _validate_webhook_url(url, primary_url=primary_url, fallback_url=fallback_url)
        self._url = url
        self._primary_url = primary_url
        self._fallback_url = fallback_url
        self._client = _client
        self._sleep = _sleep or asyncio.sleep
        self._overall_timeout = float(overall_timeout_seconds)

        # B-028: if the caller passes an explicit app_id, validate it via
        # the canonical _validate_app_id from ct_auth.resolver (same gate as
        # CTEndpointResolver). If None, we do NOT read CT_APP_ID here — the
        # payload uses event.app_id which comes from the resolver's own
        # validation, so duplicating the env read would diverge behaviour.
        if app_id is not None:
            from ct_auth.resolver import _validate_app_id

            _validate_app_id(app_id)

    def _payload(self, event: FailoverEvent) -> dict[str, Any]:
        return {
            "flip_id": str(event.flip_id),
            "event": event.event,
            "app_id": event.app_id,
            "primary_url": event.primary_url,
            "fallback_url": event.fallback_url,
            "active_url": event.active_url,
            "timestamp": event.timestamp.isoformat(),
        }

    async def notify(self, event: FailoverEvent) -> None:
        # C-007: wrap the whole attempt loop in a hard outer wall-clock bound.
        try:
            await asyncio.wait_for(self._run_attempts(event), timeout=self._overall_timeout)
        except asyncio.TimeoutError:
            _logger.warning(
                "webhook notify: overall timeout %.1fs exceeded; giving up",
                self._overall_timeout,
            )

    async def _run_attempts(self, event: FailoverEvent) -> None:
        backoff = [1.0, 2.0, 4.0]
        client = self._client
        owns_client = False
        if client is None:
            client = httpx.AsyncClient(follow_redirects=False, timeout=5.0)
            owns_client = True
        try:
            for attempt in range(3):
                try:
                    resp = await client.post(
                        self._url, json=self._payload(event), timeout=5.0
                    )
                except (httpx.HTTPError, ConnectionError, asyncio.TimeoutError) as exc:
                    # B-016: narrow the except so programming errors (TypeError,
                    # ValueError) propagate rather than being masked as "network".
                    _logger.warning(
                        "webhook attempt %d network error: %s", attempt + 1, exc
                    )
                    if attempt < 2:
                        await self._sleep(backoff[attempt])
                        continue
                    return
                status = getattr(resp, "status_code", 0)
                if 200 <= status < 300:
                    return
                if 300 <= status < 400:
                    _logger.warning(
                        "webhook responded %d — 3xx redirects are not followed (client config error)",
                        status,
                    )
                    return
                if 400 <= status < 500:
                    _logger.warning(
                        "webhook responded %d — client error, not retrying",
                        status,
                    )
                    return
                # 5xx -> retry with backoff
                if attempt < 2:
                    await self._sleep(backoff[attempt])
        finally:
            if owns_client:
                try:
                    await client.aclose()
                except Exception:  # noqa: BLE001
                    pass


# ---------------------------------------------------------------------------
# EmailNotifier
# ---------------------------------------------------------------------------


class EmailNotifier(Notifier):
    """Send failover notification emails via SMTP.

    - Address validation rejects CRLF / null / metacharacter injection at
      construction time (B2-005, test 22).
    - CT_EMAIL_BACKEND=console logs CRITICAL and returns (test 8).
    - Does NOT retry — single log on failure (B-007).
    """

    def __init__(
        self,
        recipients: Iterable[str],
        *,
        smtp_host: str | None = None,
        smtp_port: int | None = None,
        smtp_user: str | None = None,
        smtp_password: str | None = None,
        from_address: str | None = None,
    ) -> None:
        self._recipients = _validate_email_recipients(list(recipients))
        self._smtp_host = smtp_host or os.environ.get("CT_SMTP_HOST")
        self._smtp_port = smtp_port or int(os.environ.get("CT_SMTP_PORT", "587"))
        self._smtp_user = smtp_user or os.environ.get("CT_SMTP_USER")
        self._smtp_password = smtp_password or os.environ.get("CT_SMTP_PASSWORD")
        self._from_address = (
            from_address
            or os.environ.get("CT_SMTP_FROM")
            or "ct-auth@noreply.invalid"
        )

    def _backend(self) -> str:
        return os.environ.get("CT_EMAIL_BACKEND", "smtp").lower()

    async def notify(self, event: FailoverEvent) -> None:
        if self._backend() == "console":
            _logger.critical(
                "ct_auth.fallback_email_unreachable event=%s app_id=%s active=%s primary=%s fallback=%s flip_id=%s",
                event.event,
                event.app_id,
                event.active_url,
                event.primary_url,
                event.fallback_url,
                event.flip_id,
            )
            return

        def _send_sync() -> None:
            if not self._smtp_host:
                _logger.critical(
                    "ct_auth.fallback_email_unreachable no CT_SMTP_HOST configured; event=%s",
                    event.event,
                )
                return
            try:
                msg = EmailMessage()
                # B-008: header assignment raises ValueError if a field contains
                # CR/LF — distinguish this from transport errors so operators
                # can alert on injection attempts.
                try:
                    msg["Subject"] = f"[ct-auth] {event.event} {event.app_id}"
                    msg["From"] = self._from_address
                    msg["To"] = ", ".join(self._recipients)
                except ValueError as header_exc:
                    _logger.error(
                        "ct_auth.email_header_injection_attempt event=%s app_id=%r reason=%s",
                        event.event,
                        event.app_id,
                        header_exc,
                    )
                    return
                msg.set_content(
                    "Failover event:\n"
                    f"  event:       {event.event}\n"
                    f"  app_id:      {event.app_id}\n"
                    f"  primary_url: {event.primary_url}\n"
                    f"  fallback_url:{event.fallback_url}\n"
                    f"  active_url:  {event.active_url}\n"
                    f"  timestamp:   {event.timestamp.isoformat()}\n"
                    f"  flip_id:     {event.flip_id}\n"
                )
                with smtplib.SMTP(self._smtp_host, self._smtp_port, timeout=10) as server:
                    try:
                        server.starttls()
                    except smtplib.SMTPException:
                        _logger.warning("SMTP STARTTLS unavailable; continuing in plain")
                    if self._smtp_user and self._smtp_password:
                        server.login(self._smtp_user, self._smtp_password)
                    server.send_message(msg)
            except smtplib.SMTPException as exc:
                _logger.critical(
                    "ct_auth.fallback_email_unreachable smtp_transport_error=%s event=%s",
                    exc,
                    event.event,
                )
            except (OSError, ConnectionError, TimeoutError) as exc:
                _logger.critical(
                    "ct_auth.fallback_email_unreachable network_error=%s event=%s",
                    exc,
                    event.event,
                )

        # Delegate blocking I/O to a thread so we don't block the event loop.
        await asyncio.to_thread(_send_sync)

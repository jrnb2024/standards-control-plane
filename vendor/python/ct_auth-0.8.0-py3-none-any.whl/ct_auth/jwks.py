"""JWKS fetcher with caching for Control Tower public keys."""

from __future__ import annotations

import base64
import os
import time
from typing import Any
from urllib.parse import urlparse

import httpx
from cryptography.hazmat.primitives.asymmetric.rsa import RSAPublicNumbers
from cryptography.hazmat.primitives.serialization import Encoding, PublicFormat


# SEC-4: hostnames where HTTP JWKS URLs are tolerated. Anything else
# requires HTTPS or an explicit opt-in via CT_AUTH_ALLOW_INSECURE_JWKS=true.
_DEV_LOOPBACK_HOSTS = {
    "localhost",
    "127.0.0.1",
    "::1",
    "host.docker.internal",
}


def _validate_jwks_url(url: str) -> None:
    """Reject HTTP JWKS URLs unless they target a known-loopback host.

    A malicious or hijacked HTTP JWKS endpoint can MITM the public key
    used to validate JWTs and let an attacker forge tokens. The remedy
    is to require HTTPS for any non-loopback URL. Local development
    against ``http://host.docker.internal`` etc. is still allowed.

    Override (for non-standard infra): set
    ``CT_AUTH_ALLOW_INSECURE_JWKS=true`` in the environment to bypass
    the check entirely. This should NEVER be done outside dev.
    """
    if os.environ.get("CT_AUTH_ALLOW_INSECURE_JWKS", "").lower() in ("1", "true", "yes"):
        return
    parsed = urlparse(url)
    if parsed.scheme == "https":
        return
    if parsed.scheme == "http" and parsed.hostname in _DEV_LOOPBACK_HOSTS:
        return
    raise ValueError(
        f"JWKS URL must use HTTPS (got {url!r}). HTTP is only allowed for "
        f"loopback hosts ({sorted(_DEV_LOOPBACK_HOSTS)}). Set "
        f"CT_AUTH_ALLOW_INSECURE_JWKS=true to override (dev only)."
    )


def _base64url_decode(data: str) -> bytes:
    """Decode a base64url-encoded string (no padding)."""
    # Add padding if needed
    padding = 4 - len(data) % 4
    if padding != 4:
        data += "=" * padding
    return base64.urlsafe_b64decode(data)


def _jwk_to_pem(jwk: dict[str, Any]) -> bytes:
    """Convert a JWK dict (RSA) to PEM-encoded public key bytes."""
    n_bytes = _base64url_decode(jwk["n"])
    e_bytes = _base64url_decode(jwk["e"])

    n = int.from_bytes(n_bytes, byteorder="big")
    e = int.from_bytes(e_bytes, byteorder="big")

    public_numbers = RSAPublicNumbers(e=e, n=n)
    public_key = public_numbers.public_key()
    return public_key.public_bytes(
        encoding=Encoding.PEM,
        format=PublicFormat.SubjectPublicKeyInfo,
    )


class JWKSClient:
    """Fetches and caches JWKS from Control Tower.

    Usage::

        client = JWKSClient("https://ct.example.com/api/v1/.well-known/jwks.json")
        pub_key = await client.get_public_key(kid="abc123")
    """

    def __init__(
        self,
        jwks_url: str,
        cache_ttl: int = 3600,
        kid_cooldown: int = 300,
    ) -> None:
        """Initialise the JWKS client.

        Args:
            jwks_url: Full URL to the JWKS endpoint
                (e.g. ``https://ct.example.com/api/v1/.well-known/jwks.json``).
            cache_ttl: Seconds to cache the JWKS response before re-fetching.
            kid_cooldown: Seconds to suppress re-fetches for the same unknown
                kid. Prevents DoS via novel-kid amplification attacks.
        """
        _validate_jwks_url(jwks_url)
        self.jwks_url = jwks_url
        self.cache_ttl = cache_ttl
        self._kid_cooldown = kid_cooldown
        self._cache: dict[str, bytes] = {}
        self._last_fetched: float = 0.0
        self._kid_cooldown_map: dict[str, float] = {}
        self._kid_cooldown_max: int = 10_000  # Cap to prevent memory exhaustion

    def _is_cache_valid(self) -> bool:
        return bool(self._cache) and (time.monotonic() - self._last_fetched) < self.cache_ttl

    def _parse_jwks(self, jwks_data: dict[str, Any]) -> dict[str, bytes]:
        """Parse JWKS JSON into a kid -> PEM mapping."""
        keys: dict[str, bytes] = {}
        for jwk in jwks_data.get("keys", []):
            kid = jwk.get("kid")
            if kid and jwk.get("kty") == "RSA":
                keys[kid] = _jwk_to_pem(jwk)
        return keys

    async def _fetch(self) -> None:
        """Fetch JWKS from the remote endpoint (async)."""
        async with httpx.AsyncClient() as client:
            resp = await client.get(self.jwks_url, timeout=10.0)
            resp.raise_for_status()
            self._cache = self._parse_jwks(resp.json())
            self._last_fetched = time.monotonic()

    # B-027: cap sync JWKS fetch timeout to 3s. Pre-flip sync callers with
    # a captured reference to the OLD JWKSClient will only pay up to 3s per
    # call against a dead primary during a flip, rather than 10s thundering
    # herd. The async path isn't affected because it uses the event loop's
    # cooperative scheduling and is already bounded by httpx.AsyncClient's
    # default timeout settings.
    _SYNC_FETCH_TIMEOUT_SECONDS: float = 3.0

    def _fetch_sync(self) -> None:
        """Fetch JWKS from the remote endpoint (sync)."""
        resp = httpx.get(self.jwks_url, timeout=self._SYNC_FETCH_TIMEOUT_SECONDS)
        resp.raise_for_status()
        self._cache = self._parse_jwks(resp.json())
        self._last_fetched = time.monotonic()

    def _is_kid_in_cooldown(self, kid: str) -> bool:
        """Check if an unknown kid is still in its cooldown window."""
        last_seen = self._kid_cooldown_map.get(kid)
        if last_seen is None:
            return False
        return (time.monotonic() - last_seen) < self._kid_cooldown

    async def get_public_key(self, kid: str | None = None) -> bytes:
        """Get a public key by kid (async).

        If *kid* is ``None``, returns the first (or only) cached key.
        If the key is not found in cache, forces a re-fetch in case of
        key rotation — unless the kid is in the cooldown window (see
        *kid_cooldown*), in which case the re-fetch is suppressed to
        prevent DoS via novel-kid amplification attacks.

        Raises:
            ValueError: If no matching key is found after fetching.
        """
        if not self._is_cache_valid():
            await self._fetch()

        if kid and kid not in self._cache:
            if not self._is_kid_in_cooldown(kid):
                # Key rotation may have occurred -- re-fetch once
                await self._fetch()
                # Record cooldown if still not found
                if kid not in self._cache:
                    self._kid_cooldown_map[kid] = time.monotonic()
                    # Evict oldest entries to prevent memory exhaustion (CRITICAL-1)
                    while len(self._kid_cooldown_map) > self._kid_cooldown_max:
                        oldest = next(iter(self._kid_cooldown_map))
                        del self._kid_cooldown_map[oldest]

        if kid:
            pem = self._cache.get(kid)
            if pem is None:
                raise ValueError(f"No key found for kid={kid!r}")
            return pem

        # No kid specified -- return first available key
        if not self._cache:
            raise ValueError("JWKS endpoint returned no keys")
        return next(iter(self._cache.values()))

    def get_public_key_sync(self, kid: str | None = None) -> bytes:
        """Get a public key by kid (sync).

        Same behaviour as :meth:`get_public_key` but using synchronous HTTP.

        Raises:
            ValueError: If no matching key is found after fetching.
        """
        if not self._is_cache_valid():
            self._fetch_sync()

        if kid and kid not in self._cache:
            if not self._is_kid_in_cooldown(kid):
                self._fetch_sync()
                if kid not in self._cache:
                    self._kid_cooldown_map[kid] = time.monotonic()
                    # Evict oldest entries to prevent memory exhaustion (CRITICAL-1)
                    while len(self._kid_cooldown_map) > self._kid_cooldown_max:
                        oldest = next(iter(self._kid_cooldown_map))
                        del self._kid_cooldown_map[oldest]

        if kid:
            pem = self._cache.get(kid)
            if pem is None:
                raise ValueError(f"No key found for kid={kid!r}")
            return pem

        if not self._cache:
            raise ValueError("JWKS endpoint returned no keys")
        return next(iter(self._cache.values()))

    def clear_cache(self) -> None:
        """Invalidate the cached JWKS data and kid cooldown map."""
        self._cache.clear()
        self._last_fetched = 0.0
        self._kid_cooldown_map.clear()

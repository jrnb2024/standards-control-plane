"""Permission and role checking helpers for Control Tower JWT claims."""

from __future__ import annotations

from typing import Any


def has_role(claims: dict[str, Any], role: str, org_id: str | None = None) -> bool:
    """Check if the user has a specific role.

    If *org_id* is provided, checks ``org_roles[org_id]`` for the role.
    Otherwise checks the flat ``roles`` list.

    Args:
        claims: Decoded JWT claims dict.
        role: Role name to check (e.g. ``"admin"``).
        org_id: Optional org to scope the check to.
    """
    if org_id is not None:
        org_roles: dict[str, list[str]] = claims.get("org_roles", {})
        return role in org_roles.get(org_id, [])
    roles: list[str] = claims.get("roles", [])
    return role in roles


def has_permission(
    claims: dict[str, Any],
    permission: str,
    roles_permissions: dict[str, set[str]],
) -> bool:
    """Check if the user has a permission via their roles.

    Uses a caller-provided ``roles_permissions`` mapping (role name -> set of
    permission strings) to resolve permissions.  This allows consumers to
    maintain their own role-permission mapping without calling Control Tower.

    Supports wildcards:
    - ``"*"`` in a role's permissions grants everything.
    - ``"resource:*"`` matches any ``"resource:<action>"``.

    Args:
        claims: Decoded JWT claims dict.
        permission: Permission string (e.g. ``"users:read"``).
        roles_permissions: Mapping of role name to permission set.
    """
    roles: list[str] = claims.get("roles", [])
    resource = permission.split(":")[0] if ":" in permission else ""

    for role in roles:
        perms = roles_permissions.get(role, set())
        if "*" in perms:
            return True
        if permission in perms:
            return True
        if resource and f"{resource}:*" in perms:
            return True
    return False


def has_app_permission(claims: dict[str, Any], app_id: str, permission: str) -> bool:
    """Check the ``app_permissions`` claim for a specific app + permission.

    The ``app_permissions`` claim is a dict mapping app IDs to lists of
    permission strings, e.g.::

        {"fla": ["read", "write"], "acc": ["read"]}

    .. note::

        This function is incompatible with ``CT_JWT_MINIMAL_CLAIMS`` mode,
        which strips ``app_permissions`` from the JWT. When minimal claims
        are enabled, use the introspection endpoint instead.

    Args:
        claims: Decoded JWT claims dict.
        app_id: Application identifier (e.g. ``"fla"``).
        permission: Permission to check within that app.
    """
    app_perms: dict[str, list[str]] = claims.get("app_permissions", {})
    if not app_perms:
        import logging
        logging.getLogger("ct_auth").warning(
            "app_permissions claim is empty — if CT_JWT_MINIMAL_CLAIMS is enabled, "
            "use the introspection endpoint instead of require_app_permission()"
        )
    return permission in app_perms.get(app_id, [])


def get_org_roles(claims: dict[str, Any], org_id: str) -> list[str]:
    """Get the roles a user holds in a specific organisation.

    Args:
        claims: Decoded JWT claims dict.
        org_id: Organisation ID.

    Returns:
        List of role names (empty if user has no roles in that org).
    """
    org_roles: dict[str, list[str]] = claims.get("org_roles", {})
    return list(org_roles.get(org_id, []))


def is_platform_admin(claims: dict[str, Any]) -> bool:
    """Check if the user holds ``platform_admin`` in any organisation.

    This mirrors the Control Tower server behaviour where
    ``platform_admin`` in *any* org grants global access.
    """
    org_roles: dict[str, list[str]] = claims.get("org_roles", {})
    for roles in org_roles.values():
        if "platform_admin" in roles:
            return True
    # Fallback: check flat roles list (backward compat / minimal claims mode)
    return "platform_admin" in claims.get("roles", [])

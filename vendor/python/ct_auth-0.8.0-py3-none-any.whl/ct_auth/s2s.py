"""Service-to-service (S2S) client for Control Tower authenticated calls.

Usage::

    from ct_auth.s2s import ServiceAccountClient

    async with ServiceAccountClient(
        ct_base_url="https://ct.example.com",
        api_key="ct_sa_...",
    ) as client:
        me = await client.whoami()
        resp = await client.request("GET", "/api/v1/some-endpoint")
"""

from __future__ import annotations

import asyncio
import hashlib
import logging
import time
from datetime import datetime, timezone
from typing import Any

import httpx

_logger = logging.getLogger("ct_auth.s2s")

# Default introspection interval (seconds)
_INTROSPECT_INTERVAL = 300


class ServiceAccountClient:
    """HTTP client authenticated as a Control Tower service account.

    Auto-injects X-API-Key, X-Org-Id, X-CT-Timestamp on every request.
    Performs periodic /me introspection to detect rotation/scope changes.
    """

    def __init__(
        self,
        ct_base_url: str,
        api_key: str,
        org_id: str | None = None,
        timeout: float = 30.0,
        introspect_interval: float = _INTROSPECT_INTERVAL,
    ) -> None:
        self._base_url = ct_base_url.rstrip("/")
        self._api_key = api_key
        self._org_id = org_id
        self._timeout = timeout
        self._introspect_interval = introspect_interval
        self._sa_info: dict[str, Any] | None = None
        self._last_introspect: float = 0.0
        self._client: httpx.AsyncClient | None = None

    async def __aenter__(self) -> ServiceAccountClient:
        self._client = httpx.AsyncClient(timeout=self._timeout)
        # Discover org_id via /me if not provided
        if self._org_id is None:
            try:
                info = await self.whoami()
                self._org_id = info.get("org_id")
            except Exception:
                await self._client.aclose()
                self._client = None
                raise
        return self

    async def __aexit__(self, *args: Any) -> None:
        if self._client:
            await self._client.aclose()
            self._client = None

    def _build_headers(self) -> dict[str, str]:
        """Build standard headers for every request."""
        headers: dict[str, str] = {
            "X-API-Key": self._api_key,
            "X-CT-Timestamp": datetime.now(timezone.utc).isoformat(),
            "Accept": "application/json",
        }
        if self._org_id:
            headers["X-Org-Id"] = self._org_id
        return headers

    async def whoami(self) -> dict[str, Any]:
        """Call GET /api/v1/service-accounts/me and return the SA info."""
        client = self._ensure_client()
        resp = await client.get(
            f"{self._base_url}/api/v1/service-accounts/me",
            headers=self._build_headers(),
        )
        resp.raise_for_status()
        self._sa_info = resp.json()
        self._last_introspect = time.monotonic()
        return self._sa_info

    async def request(
        self,
        method: str,
        path: str,
        **kwargs: Any,
    ) -> httpx.Response:
        """Make an authenticated request to Control Tower.

        Retries on 429/5xx with simple exponential backoff.
        """
        client = self._ensure_client()
        url = f"{self._base_url}{path}"
        # Caller headers are applied first, then auth headers override
        # to prevent accidental or malicious replacement of X-API-Key etc.
        caller_headers = kwargs.pop("headers", {})
        headers = {**caller_headers, **self._build_headers()}

        # Periodic introspection
        if time.monotonic() - self._last_introspect > self._introspect_interval:
            try:
                await self.whoami()
            except Exception:
                _logger.warning("Periodic /me introspection failed")

        # Retry loop with exponential backoff on 429/5xx
        max_retries = 3
        last_resp: httpx.Response | None = None
        for attempt in range(max_retries + 1):
            last_resp = await client.request(method, url, headers=headers, **kwargs)
            if last_resp.status_code == 429 or last_resp.status_code >= 500:
                if attempt < max_retries:
                    delay = 0.5 * (2 ** attempt)
                    retry_after = last_resp.headers.get("Retry-After")
                    if retry_after:
                        try:
                            delay = max(delay, float(retry_after))
                        except ValueError:
                            pass
                    await asyncio.sleep(delay)
                    continue
            return last_resp
        assert last_resp is not None  # loop always runs at least once
        return last_resp

    def _ensure_client(self) -> httpx.AsyncClient:
        if self._client is None:
            _logger.warning("ServiceAccountClient used without context manager — connections may leak")
            self._client = httpx.AsyncClient(timeout=self._timeout)
        return self._client

    @property
    def org_id(self) -> str | None:
        return self._org_id

    @property
    def sa_info(self) -> dict[str, Any] | None:
        return self._sa_info

    @property
    def api_key_hash(self) -> str:
        """SHA-256 hash of the API key (for cache keying, never log the raw key)."""
        return hashlib.sha256(self._api_key.encode()).hexdigest()

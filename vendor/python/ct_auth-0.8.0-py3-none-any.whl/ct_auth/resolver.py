"""CT endpoint resolver with primary/fallback health-checked failover.

This module implements WP-SCC-2 (PLAN-CT-004 v0.5):

- :class:`CTEndpointResolver` — state machine (healthy / failed_over / both_down)
  with async health-check loop, bound to an app lifespan shutdown event.
- :class:`FailoverEvent` — frozen dataclass describing a state transition.
- :class:`Notifier` — ABC; :class:`NoopNotifier` is the default.
- :class:`CompositeNotifier` — fan-out with per-notifier timeout, idempotence
  via flip_id, and (event, active_url, primary_url) dedup window.
- :exc:`CTBothDownError` — raised when both primary and fallback fail
  their health checks consecutively and callers ask for the active URL.

Design decisions (from PLAN-CT-004 § 2):

- **D-014** CT is context-aware; fallback lives in apps.
- **D-015** Noisy fallback notification — fire-and-forget with backoff.
- **D-016** Distinct JWT key pairs per CT instance + stateful single-JWKS.
- **D-019** Resolver lifecycle is per-process; optional Redis cross-worker dedup.
- **D-020** Health-check target is ``/api/v1/.well-known/jwks.json`` — not ``/health``.
- **D-021** Fallback URL is environment-scoped (unset in staging).

Fire-and-forget hot path (AC-2.14, B2-004): the resolver's ``_emit_flip``
method schedules notifier dispatch via :func:`asyncio.create_task` and returns
immediately. Outstanding notification tasks are tracked in
``self._pending_notification_tasks`` and bounded at
``NOTIFICATION_TASK_BACKLOG_MAX`` (default 256). Task exceptions are logged
via ``add_done_callback`` and never propagate to the hot path.
"""

from __future__ import annotations

import asyncio
import logging
import os
import itertools
import re
import time
from abc import ABC, abstractmethod
from collections import deque
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Awaitable, Callable, Iterable, Literal
from urllib.parse import urlparse
from uuid import UUID, uuid4

import httpx

from ct_auth.bff import _is_dev_env, _validate_ct_base_url

_logger = logging.getLogger("ct_auth.resolver")

# ---------------------------------------------------------------------------
# Types
# ---------------------------------------------------------------------------

ResolverState = Literal["healthy", "failed_over", "both_down"]
_VALID_EVENT_NAMES = frozenset({"failed_over", "recovered", "both_down"})

# A-401: per-process counter appended to the dev-mode app_id fallback so
# two CTEndpointResolvers constructed in the same Python process get
# distinct ids. `os.getpid()` alone collides for intra-process peers.
_APP_ID_FALLBACK_COUNTER = itertools.count(1)

# \A..\Z anchors are required so that trailing newlines are NOT accepted by
# the default ^..$ behaviour (B-001). fullmatch is used at the call site as
# belt-and-braces.
_APP_ID_REGEX = re.compile(r"\A[a-z0-9][a-z0-9._-]{0,63}\Z")


class CTBothDownError(RuntimeError):
    """Raised when both primary and fallback CT instances are failing health checks."""


@dataclass(frozen=True)
class FailoverEvent:
    """Describes a single resolver state transition.

    All fields are required — the webhook payload allowlist (AC-2.16) is
    enforced by requiring exactly this set of fields in
    :meth:`ct_auth.notifiers.WebhookNotifier._payload`.
    """

    flip_id: UUID
    event: Literal["failed_over", "recovered", "both_down"]
    app_id: str
    primary_url: str
    fallback_url: str
    active_url: str
    timestamp: datetime

    def __post_init__(self) -> None:
        # Runtime-enforce the Literal (A-015 / B-012). Python dataclasses do
        # not validate Literal types by themselves; this closes the gap.
        if self.event not in _VALID_EVENT_NAMES:
            raise ValueError(
                f"FailoverEvent.event must be one of {sorted(_VALID_EVENT_NAMES)}, "
                f"got {self.event!r}"
            )
        # B-029: every string field must be free of control characters so
        # direct FailoverEvent(...) constructions from test harnesses or new
        # notifier types cannot bypass the URL validators.
        forbidden = "\r\n\0\t\v\f"
        for field_name in ("app_id", "primary_url", "fallback_url", "active_url"):
            value = getattr(self, field_name)
            if not isinstance(value, str):
                raise ValueError(f"FailoverEvent.{field_name} must be str")
            for ch in forbidden:
                if ch in value:
                    raise ValueError(
                        f"FailoverEvent.{field_name} contains forbidden control "
                        f"character {ch!r}: {value!r}"
                    )


# ---------------------------------------------------------------------------
# Notifier ABC + Noop
# ---------------------------------------------------------------------------


class Notifier(ABC):
    """Base interface for resolver notifiers.

    :meth:`notify` MUST NOT raise — exceptions are logged by the resolver's
    ``add_done_callback`` and never break the hot path.
    """

    @abstractmethod
    async def notify(self, event: FailoverEvent) -> None:  # pragma: no cover
        ...


class NoopNotifier(Notifier):
    """Notifier that discards all events. The default for apps that don't configure one."""

    async def notify(self, event: FailoverEvent) -> None:
        _logger.debug("NoopNotifier: dropped event %s %s", event.event, event.active_url)


# ---------------------------------------------------------------------------
# CompositeNotifier — fan-out with timeout + dedup + idempotence
# ---------------------------------------------------------------------------


class CompositeNotifier(Notifier):
    """Fans a :class:`FailoverEvent` out to multiple notifiers.

    - Bounded wall-clock: :func:`asyncio.wait` cancels laggards after
      ``max_notification_wall_seconds`` (AC-2.14, test 11).
    - Dedup: ``(event, active_url, primary_url)`` suppressed within
      ``dedup_window_seconds`` (AC-2.15, test 12). Distinct ``active_url``
      values defeat dedup — three cross-env flips produce three notifications
      (test 21).
    - Idempotence: a seen ``flip_id`` is never re-delivered (test 14).
    - Isolation: a raising notifier does not prevent others from firing
      (test 13) and never propagates (AC-2.17, test 17).
    """

    def __init__(
        self,
        notifiers: Iterable[Notifier],
        *,
        max_notification_wall_seconds: float = 10.0,
        dedup_window_seconds: float = 60.0,
    ) -> None:
        self._notifiers: list[Notifier] = list(notifiers)
        self._max_wall = float(max_notification_wall_seconds)
        self._dedup_window = float(dedup_window_seconds)
        # Transition-debounced dedup: remember the most recent (event, active_url,
        # primary_url) key and suppress only exact consecutive repeats within the
        # window. Distinct transitions (even if they later re-visit a key)
        # always fire — three flips fb->p->fb produce three notifications.
        # This intentionally diverges from a naive "windowed set" reading of
        # AC-2.15 because AC-2.22 test 21 pins the transition semantics. See
        # implementation_notes.md § 2 for the rationale.
        self._last_key: tuple[str, str, str] | None = None
        self._last_key_time: float = 0.0
        # Use deque for O(1) eviction (A-012); the set is the fast membership
        # check, the deque tracks insertion order for bounded FIFO eviction.
        # B-023: each entry is (flip_id, monotonic_ts) so a long-running
        # process can expire stale idempotence records without relying on the
        # FIFO cap alone.
        self._seen_flip_ids_max = 1024
        self._seen_flip_ids_ttl = max(86400.0, dedup_window_seconds * 10.0)
        self._seen_flip_ids: set[UUID] = set()
        self._seen_flip_ids_order: deque[tuple[UUID, float]] = deque(
            maxlen=self._seen_flip_ids_max
        )

    def _is_deduped(self, event: FailoverEvent) -> bool:
        key = (event.event, event.active_url, event.primary_url)
        now = time.monotonic()
        if self._last_key == key and (now - self._last_key_time) < self._dedup_window:
            return True
        self._last_key = key
        self._last_key_time = now
        return False

    def _remember_flip_id(self, flip_id: UUID) -> bool:
        """Return True if this flip_id is new (should fire)."""
        now = time.monotonic()
        # B-023: sweep TTL-expired entries before the membership check. This
        # keeps the set hygienic in long-running processes.
        while self._seen_flip_ids_order and (
            now - self._seen_flip_ids_order[0][1] > self._seen_flip_ids_ttl
        ):
            evicted_id, _ = self._seen_flip_ids_order.popleft()
            self._seen_flip_ids.discard(evicted_id)
        if flip_id in self._seen_flip_ids:
            return False
        # deque auto-evicts when maxlen is exceeded; mirror that eviction in
        # the set so membership reflects live entries only.
        if len(self._seen_flip_ids_order) == self._seen_flip_ids_max:
            evicted_id, _ = self._seen_flip_ids_order[0]
            self._seen_flip_ids.discard(evicted_id)
        self._seen_flip_ids_order.append((flip_id, now))
        self._seen_flip_ids.add(flip_id)
        return True

    async def notify(self, event: FailoverEvent) -> None:
        if not self._remember_flip_id(event.flip_id):
            _logger.debug("CompositeNotifier: duplicate flip_id %s suppressed", event.flip_id)
            return
        if self._is_deduped(event):
            _logger.debug(
                "CompositeNotifier: deduped (event=%s, active=%s) within %ss window",
                event.event,
                event.active_url,
                self._dedup_window,
            )
            return

        async def _safe(notifier: Notifier) -> None:
            try:
                await notifier.notify(event)
            except asyncio.CancelledError:
                raise
            except Exception as exc:  # noqa: BLE001
                _logger.warning(
                    "notifier %s raised: %s",
                    type(notifier).__name__,
                    exc,
                    exc_info=True,
                )

        if not self._notifiers:
            return

        tasks = [asyncio.create_task(_safe(n)) for n in self._notifiers]
        done, pending = await asyncio.wait(tasks, timeout=self._max_wall)
        for t in pending:
            t.cancel()
        # Drain BOTH sets (B-017). Previously only `pending` was drained;
        # cancelled-but-done tasks in `done` could emit "Task exception was
        # never retrieved" warnings.
        await asyncio.gather(*done, *pending, return_exceptions=True)


# ---------------------------------------------------------------------------
# CTEndpointResolver
# ---------------------------------------------------------------------------


def _validate_app_id(app_id: str | None) -> str:
    """Validate CT_APP_ID against the regex, falling back to HOSTNAME / hostname.

    Uses ``fullmatch`` on ``\\A..\\Z`` so trailing newlines / control characters
    cannot slip through (B-001).

    Semantics:
    - If ``app_id`` is a non-empty string, it MUST ``fullmatch`` the regex.
      Malformed explicit values raise ``ValueError`` — no silent downgrade
      (A-007).
    - If ``app_id`` is ``None`` or an empty string, try ``HOSTNAME`` env var.
    - If ``HOSTNAME`` is unset or malformed, derive a sanitised value from
      ``socket.gethostname()`` so dev / test environments work without needing
      to configure an env var. If that too fails, raise.
    """
    import socket as _socket

    # Case 1: explicit non-empty value must pass the regex strictly.
    if app_id:
        if not _APP_ID_REGEX.fullmatch(app_id):
            raise ValueError(
                r"CT_APP_ID must match \A[a-z0-9][a-z0-9._-]{0,63}\Z "
                f"(got {app_id!r}) (B2-007)"
            )
        return app_id

    # Case 2: HOSTNAME env var
    hostname_env = os.environ.get("HOSTNAME") or ""
    if hostname_env and _APP_ID_REGEX.fullmatch(hostname_env):
        return hostname_env

    # Case 3: socket.gethostname() sanitised + pid + intra-process counter
    # suffix. B-032: on macOS `socket.gethostname()` returns
    # `mac-studio.local` which collides across co-located apps on the
    # same dev machine — PID disambiguates cross-process.
    # A-401: PID alone ALSO collides for TWO resolvers constructed inside
    # the same Python process — append an intra-process counter so each
    # construction gets a distinct id even in tests or multi-resolver setups.
    # In non-dev ENV, we DO NOT use this fallback and raise instead —
    # production deployments must always set CT_APP_ID explicitly.
    env_name = os.environ.get("ENV", "").strip().lower()
    raw = ""
    sanitised = ""
    if env_name in ("development", "test"):
        raw = _socket.gethostname().casefold()
        sanitised = re.sub(r"[^a-z0-9._-]", "-", raw)
        sanitised = sanitised.lstrip("._-")[:32] or "ct-auth-app"
        counter = next(_APP_ID_FALLBACK_COUNTER)
        with_suffix = f"{sanitised}-{os.getpid()}-{counter}"[:64]
        if _APP_ID_REGEX.fullmatch(with_suffix):
            return with_suffix

    # Case 4: genuinely nothing works — fail closed. Production must set
    # CT_APP_ID explicitly (AC-2.32 documents this).
    raise ValueError(
        r"Could not derive a valid CT_APP_ID matching \A[a-z0-9][a-z0-9._-]{0,63}\Z "
        f"(CT_APP_ID={app_id!r}, HOSTNAME={hostname_env!r}, "
        f"env={env_name!r}, socket.gethostname()={raw!r}, sanitised={sanitised!r}) "
        "(B2-007). Set CT_APP_ID explicitly in production."
    )


def _check_production_guard() -> bool:
    """Enforce B2-003 / N3-003 — dev escape hatch only allowed in ENV=development/test.

    Returns True if CT_DEVELOPMENT_MODE=local-only AND ENV is dev/test; False otherwise.
    Raises ValueError when the escape hatch is requested from an unsafe environment.
    """
    if os.environ.get("CT_DEVELOPMENT_MODE") != "local-only":
        return False
    env = os.environ.get("ENV", "").lower()
    if env not in ("development", "test"):
        raise ValueError(
            "CT_DEVELOPMENT_MODE=local-only is only allowed when ENV=development or ENV=test. "
            f"Current ENV={env!r}. Unset ENV is treated as production-safe and rejects the escape hatch."
        )
    return True


class CTEndpointResolver:
    """Health-checked primary/fallback resolver for Control Tower.

    AC-2.1 constructor parameters; AC-2.2 ``active_base_url()``; AC-2.3
    health-check loop; AC-2.4 bounded shutdown; AC-2.5 SSRF validation
    on both primary and fallback.

    **Hot path:** a slow or hanging notifier CANNOT block state transitions
    because :meth:`_emit_flip` dispatches via :func:`asyncio.create_task`.
    Outstanding tasks are tracked in :attr:`_pending_notification_tasks`
    and capped at :attr:`NOTIFICATION_TASK_BACKLOG_MAX`.
    """

    NOTIFICATION_TASK_BACKLOG_MAX: int = 256
    # Cap on consecutive 429 responses from the primary's health endpoint
    # before we treat the primary as failing (B-005). At 10 × 30s = 5 minutes
    # of continuous rate-limit, something is probably wrong — force a
    # treatment-as-failure and let the state machine flip.
    MAX_CONSECUTIVE_RATE_LIMITS: int = 10

    def __init__(
        self,
        primary_url: str,
        fallback_url: str,
        *,
        health_check_interval_seconds: float = 30.0,
        failure_threshold: int = 3,
        recovery_threshold: int = 2,
        notifier: Notifier | None = None,
        shutdown_event: asyncio.Event | None = None,
        http_timeout_seconds: float = 5.0,
        app_id: str | None = None,
        notification_backlog_max: int | None = None,
    ) -> None:
        # Snapshot ENV once so mid-construction env mutations are ignored (B-006).
        env_snapshot = os.environ.get("ENV", "")
        # Production guard for the dev escape hatch (B2-003, N3-003).
        self.bypassed: bool = _check_production_guard()

        # SSRF + scheme validation on BOTH endpoints (AC-2.5, B-003, A-010).
        self.primary_url: str = _validate_ct_base_url(primary_url, label="primary_url")
        self.fallback_url: str = _validate_ct_base_url(fallback_url, label="fallback_url")

        # Reject primary == fallback (B-007 / B-022). An operator copy-paste
        # error that sets CT_FALLBACK_URL to the same host as CT_BASE_URL
        # silently disables failover; fail-fast at construction instead.
        # B-022: normalise scheme default ports so `http://a:80` and `http://a`
        # are recognised as identical.
        def _normalise(url: str) -> tuple[str, int | None]:
            p = urlparse(url)
            host = (p.hostname or "").rstrip(".").casefold()
            port = p.port
            if port is None:
                port = {"http": 80, "https": 443}.get(p.scheme)
            return host, port

        p_host, p_port = _normalise(self.primary_url)
        f_host, f_port = _normalise(self.fallback_url)
        if p_host and (p_host, p_port) == (f_host, f_port):
            raise ValueError(
                "primary_url and fallback_url must be distinct hosts "
                f"(both resolved to {p_host}:{p_port}). A misconfigured equal "
                "fallback silently disables failover."
            )

        self.health_check_interval_seconds = float(health_check_interval_seconds)
        self.failure_threshold = int(failure_threshold)
        self.recovery_threshold = int(recovery_threshold)
        self.http_timeout_seconds = float(http_timeout_seconds)
        self._notifier: Notifier = notifier if notifier is not None else NoopNotifier()
        self._shutdown_event: asyncio.Event | None = shutdown_event
        if notification_backlog_max is not None:
            self.NOTIFICATION_TASK_BACKLOG_MAX = int(notification_backlog_max)  # type: ignore[misc]

        # Strict app_id validation (A-007, B-001). Fail-fast if the env var /
        # explicit arg is malformed AND HOSTNAME fallback is also malformed.
        env_app_id = app_id if app_id is not None else os.environ.get("CT_APP_ID")
        self.app_id = _validate_app_id(env_app_id)

        # State machine
        self._state: ResolverState = "healthy"
        self._primary_failures = 0
        self._primary_successes = 0
        self._fallback_failures = 0
        self._fallback_successes = 0
        # A-201: symmetric rate-limit streak counters for BOTH endpoints so
        # a persistently-429 fallback cannot starve the state machine.
        self._primary_rate_limit_streak = 0
        self._fallback_rate_limit_streak = 0

        # Async task management
        self._task: asyncio.Task | None = None
        self._http_client: Any = None  # lazy, set by start() or tests
        self._owns_http_client: bool = False
        self._pending_notification_tasks: set[asyncio.Task] = set()
        self._state_subscribers: list[Callable[[ResolverState], None]] = []

        _logger.info(
            "CTEndpointResolver initialised primary=%s fallback=%s interval=%ss thresholds=(%d,%d) bypassed=%s",
            self.primary_url,
            self.fallback_url,
            self.health_check_interval_seconds,
            self.failure_threshold,
            self.recovery_threshold,
            self.bypassed,
        )

    # ------------------------------------------------------------------
    # Public surface
    # ------------------------------------------------------------------

    @property
    def state(self) -> ResolverState:
        return self._state

    def active_base_url(self) -> str:
        """Return the currently active CT base URL, or raise CTBothDownError.

        AC-2.2. While bypassed (dev escape hatch), always returns the primary.
        """
        if self.bypassed:
            return self.primary_url
        if self._state == "both_down":
            raise CTBothDownError(
                f"Both primary={self.primary_url} and fallback={self.fallback_url} failed health checks"
            )
        if self._state == "failed_over":
            return self.fallback_url
        return self.primary_url

    def active_jwks_url(self) -> str:
        base = self.active_base_url()
        return f"{base}/api/v1/.well-known/jwks.json"

    def subscribe(self, callback: Callable[[ResolverState], None]) -> None:
        """Subscribe to state transitions (used by StatefulJWKSClient, AC-2.9)."""
        self._state_subscribers.append(callback)

    def unsubscribe(self, callback: Callable[[ResolverState], None]) -> None:
        """Remove a previously-registered state-change callback (A-013)."""
        try:
            self._state_subscribers.remove(callback)
        except ValueError:
            pass

    async def start(self) -> None:
        """Start the background health-check task (AC-2.3)."""
        if self.bypassed or self._task is not None:
            return
        if self._http_client is None:
            self._http_client = httpx.AsyncClient(timeout=self.http_timeout_seconds)
            self._owns_http_client = True
        self._task = asyncio.create_task(self._run_loop(), name="ct-auth.resolver")

    async def close(self) -> None:
        """Cancel the background task and close owned resources (AC-2.4, AC-2.20).

        A-014: when we cancel our own ``_task``, :func:`asyncio.wait_for`
        propagates ``CancelledError`` on Python 3.11+. That's expected and
        swallowed. But if the *outer* task calling ``close()`` is itself being
        cancelled, we MUST allow the cancellation to propagate once cleanup
        is done — otherwise a double-SIGTERM shutdown gets stuck.
        """
        if self._shutdown_event is not None and not self._shutdown_event.is_set():
            self._shutdown_event.set()
        if self._task is not None:
            self._task.cancel()
            try:
                await asyncio.wait_for(self._task, timeout=1.0)
            except asyncio.TimeoutError:
                _logger.warning("resolver close: background task did not exit within 1s")
            except asyncio.CancelledError:
                # Swallow — we cancelled it on purpose. The outer-task
                # cancellation check happens at the end of close().
                pass
            self._task = None
        # Cancel outstanding notifier tasks
        for t in list(self._pending_notification_tasks):
            t.cancel()
        if self._pending_notification_tasks:
            await asyncio.gather(*self._pending_notification_tasks, return_exceptions=True)
        self._pending_notification_tasks.clear()
        # Close owned http client
        if self._owns_http_client and self._http_client is not None:
            try:
                await self._http_client.aclose()
            except Exception:  # noqa: BLE001
                pass
            self._http_client = None
            self._owns_http_client = False
        # Clear state subscribers (A-013 hygiene).
        self._state_subscribers.clear()
        # A-014 / B-031: if the outer task is being cancelled, propagate the
        # cancel once we've finished cleanup. `Task.cancelling()` is Python
        # 3.11+. Our pyproject says `requires-python >= 3.9` but D-016 relies
        # on `asyncio.to_thread` (3.9+) as the floor, so in practice we run
        # on 3.11+ everywhere; keep a hasattr guard for the edge case.
        current = asyncio.current_task()
        if current is not None and hasattr(current, "cancelling"):
            if current.cancelling() > 0:
                raise asyncio.CancelledError()

    # ------------------------------------------------------------------
    # Health-check internals
    # ------------------------------------------------------------------

    async def _run_loop(self) -> None:
        while True:
            if self._shutdown_event is not None and self._shutdown_event.is_set():
                return
            try:
                await self._run_health_iteration()
            except asyncio.CancelledError:
                raise
            except Exception as exc:  # noqa: BLE001
                _logger.warning("resolver health iteration raised: %s", exc, exc_info=True)
            try:
                await asyncio.sleep(self.health_check_interval_seconds)
            except asyncio.CancelledError:
                raise

    async def _run_health_iteration(self) -> None:
        """One iteration of the health-check state machine.

        - Always probes primary.
        - Probes fallback when state is not HEALTHY (to detect both-down and recovery).
        - Returns None from ``_health_check`` when the response is 429 (rate-limit
          backoff, A2-004) — counters are unchanged up to the B-005 streak cap.
        """
        primary_result = await self._health_check(self.primary_url)
        if primary_result is True:
            self._primary_successes += 1
            self._primary_failures = 0
            self._primary_rate_limit_streak = 0
        elif primary_result is False:
            self._primary_failures += 1
            self._primary_successes = 0
            self._primary_rate_limit_streak = 0
        else:
            # None == 429. Track streak; if too long, treat as failure to
            # prevent indefinite failover suppression (B-005).
            self._primary_rate_limit_streak += 1
            if self._primary_rate_limit_streak >= self.MAX_CONSECUTIVE_RATE_LIMITS:
                _logger.warning(
                    "ct_auth.persistent_rate_limit primary=%r streak=%d — "
                    "treating as failure to unstick resolver",
                    self.primary_url,
                    self._primary_rate_limit_streak,
                )
                self._primary_failures += 1
                self._primary_successes = 0

        fallback_result: bool | None = None
        if self._state in ("failed_over", "both_down"):
            fallback_result = await self._health_check(self.fallback_url)
            if fallback_result is True:
                self._fallback_successes += 1
                self._fallback_failures = 0
                self._fallback_rate_limit_streak = 0
            elif fallback_result is False:
                self._fallback_failures += 1
                self._fallback_successes = 0
                self._fallback_rate_limit_streak = 0
            else:
                # A-201: 429 on fallback — track streak; escalate symmetric
                # to the primary so an eternally-rate-limited fallback
                # cannot hide a real outage.
                self._fallback_rate_limit_streak += 1
                if self._fallback_rate_limit_streak >= self.MAX_CONSECUTIVE_RATE_LIMITS:
                    _logger.warning(
                        "ct_auth.fallback_rate_limit_starvation fallback=%r streak=%d — "
                        "treating as failure to unstick resolver",
                        self.fallback_url,
                        self._fallback_rate_limit_streak,
                    )
                    self._fallback_failures += 1
                    self._fallback_successes = 0

        await self._apply_state_transitions()

    async def _apply_state_transitions(self) -> None:
        old = self._state
        if old == "healthy":
            if self._primary_failures >= self.failure_threshold:
                # Probe fallback once before declaring failed_over / both_down.
                # A-005: tri-state — 429 from fallback must NOT trigger both_down.
                # A-201: track inline-probe rate-limit streak to cap starvation.
                fb = await self._health_check(self.fallback_url)
                if fb is True:
                    self._state = "failed_over"
                    self._primary_successes = 0
                    self._fallback_failures = 0
                    self._fallback_successes = 1
                    self._fallback_rate_limit_streak = 0
                elif fb is False:
                    # Primary failed AND fallback failed -> both down
                    self._state = "both_down"
                    self._fallback_failures = 1
                    self._fallback_rate_limit_streak = 0
                else:
                    # fb is None (429) — symmetric 429 escalation path.
                    self._fallback_rate_limit_streak += 1
                    if self._fallback_rate_limit_streak >= self.MAX_CONSECUTIVE_RATE_LIMITS:
                        _logger.warning(
                            "ct_auth.fallback_rate_limit_starvation fallback=%r streak=%d — "
                            "inline probe kept returning 429; declaring both_down",
                            self.fallback_url,
                            self._fallback_rate_limit_streak,
                        )
                        self._state = "both_down"
                        self._fallback_failures = 1
                    else:
                        # Stay healthy this iteration; next iteration will
                        # re-evaluate. Reset primary failure counter so we don't
                        # permanently sit at threshold.
                        self._primary_failures = 0
        elif old == "failed_over":
            if self._primary_successes >= self.recovery_threshold:
                self._state = "healthy"
                self._primary_failures = 0
                self._fallback_successes = 0
            elif self._fallback_failures >= self.failure_threshold:
                self._state = "both_down"
        elif old == "both_down":
            # A-004: primary recovery MUST be a valid path out of both_down,
            # not just fallback recovery. Prefer primary when both recover.
            if self._primary_successes >= self.recovery_threshold:
                self._state = "healthy"
                self._primary_failures = 0
                self._fallback_successes = 0
                self._fallback_failures = 0
            elif self._fallback_successes >= 1:
                self._state = "failed_over"
                self._fallback_failures = 0

        if self._state != old:
            # A-018: distinct log event name per transition class, plus the
            # full from→to chain. Observability consumers can grep
            # ct_auth.both_down specifically.
            if self._state == "both_down":
                log_event = "ct_auth.both_down"
            elif old == "both_down":
                log_event = "ct_auth.recovered_from_both_down"
            else:
                log_event = "ct_auth.fallback_flipped"
            _logger.warning(
                "%s from=%s to=%s primary=%r fallback=%r",
                log_event,
                old,
                self._state,
                self.primary_url,
                self.fallback_url,
            )
            for sub in list(self._state_subscribers):
                try:
                    sub(self._state)
                except Exception as exc:  # noqa: BLE001
                    _logger.warning("state subscriber raised: %s", exc)
            # Emit notification (fire-and-forget).
            if self._state == "healthy":
                event_name = "recovered"
                active_for_event = self.primary_url
            elif self._state == "failed_over":
                event_name = "failed_over"
                active_for_event = self.fallback_url
            else:
                event_name = "both_down"
                # A-008: use a sentinel rather than a misleading URL.
                active_for_event = ""
            await self._emit_flip(event_name, active_for_event)

    async def _health_check(self, url: str) -> bool | None:
        """Ping ``{url}/api/v1/.well-known/jwks.json`` and return a tri-state result.

        Returns:
            True  -- 200 with non-empty RSA keys array (healthy)
            False -- any other non-429 failure (unhealthy, counts towards threshold)
            None  -- 429 rate-limited (skip this iteration, A2-004)

        NOTE: tests monkey-patch this method with a bool-returning callable.
        The state machine interprets None by leaving counters unchanged;
        test stubs that return bool are still handled correctly.
        """
        if self._http_client is None:
            return False
        try:
            resp = await self._http_client.get(
                f"{url}/api/v1/.well-known/jwks.json", timeout=self.http_timeout_seconds
            )
        except Exception as exc:  # noqa: BLE001
            _logger.debug("resolver health check network error for %s: %s", url, exc)
            return False

        status = getattr(resp, "status_code", 0)
        if status == 429:
            return None  # soft backoff
        if status != 200:
            return False
        try:
            body = resp.json()
        except Exception:  # noqa: BLE001
            return False
        keys = body.get("keys") if isinstance(body, dict) else None
        if not isinstance(keys, list) or not keys:
            return False
        for k in keys:
            if not isinstance(k, dict):
                return False
            if k.get("kty") != "RSA" or not k.get("kid"):
                return False
        return True

    # ------------------------------------------------------------------
    # Notification dispatch (fire-and-forget)
    # ------------------------------------------------------------------

    async def _emit_flip(self, event_name: str, active_url: str) -> None:
        """Schedule notifier dispatch as a fire-and-forget task (AC-2.14, B2-004).

        Bounded backlog: tasks exceeding :attr:`NOTIFICATION_TASK_BACKLOG_MAX`
        log a warning and are dropped (log-only degradation, N3-004).
        """
        # Runtime enforce the allowlist (B-012). FailoverEvent.__post_init__
        # will also enforce, but checking here lets the log line include
        # the state context.
        if event_name not in _VALID_EVENT_NAMES:
            raise AssertionError(
                f"_emit_flip received invalid event_name={event_name!r}; "
                f"must be one of {sorted(_VALID_EVENT_NAMES)}"
            )
        if len(self._pending_notification_tasks) >= self.NOTIFICATION_TASK_BACKLOG_MAX:
            # B-010: include enough context to triage a saturated backlog.
            _logger.warning(
                "ct_auth.notification_backlog_saturated backlog=%d max=%d "
                "dropping event=%s state=%s primary=%r fallback=%r active=%r",
                len(self._pending_notification_tasks),
                self.NOTIFICATION_TASK_BACKLOG_MAX,
                event_name,
                self._state,
                self.primary_url,
                self.fallback_url,
                active_url,
            )
            return

        event = FailoverEvent(
            flip_id=uuid4(),
            event=event_name,  # runtime-checked by FailoverEvent.__post_init__
            app_id=self.app_id,
            primary_url=self.primary_url,
            fallback_url=self.fallback_url,
            active_url=active_url,
            timestamp=datetime.now(timezone.utc),
        )

        task = asyncio.create_task(self._notifier.notify(event))
        self._pending_notification_tasks.add(task)

        def _on_done(t: asyncio.Task) -> None:
            self._pending_notification_tasks.discard(t)
            try:
                exc = t.exception()
            except (asyncio.CancelledError, asyncio.InvalidStateError):
                return
            if exc is not None:
                _logger.warning("notifier task raised", exc_info=exc)

        task.add_done_callback(_on_done)


# ---------------------------------------------------------------------------
# Public re-exports (C-003)
# ---------------------------------------------------------------------------
# The plan's AC-2.11 text says "EmailNotifier, WebhookNotifier, CompositeNotifier,
# NoopNotifier are all provided in ct_auth.resolver". We keep Email/Webhook in
# ct_auth.notifiers for module hygiene (they pull in extra deps and validators)
# but re-export them here so `from ct_auth.resolver import EmailNotifier` works.

def __getattr__(name: str) -> Any:
    if name in ("EmailNotifier", "WebhookNotifier"):
        from ct_auth import notifiers as _notifiers_mod

        return getattr(_notifiers_mod, name)
    raise AttributeError(f"module 'ct_auth.resolver' has no attribute {name!r}")

"""Backend-for-Frontend (BFF) auth routes for ct-auth-python.

Provides ``create_bff_routes()`` which returns a ``BFFRoutes`` object
containing a FastAPI ``APIRouter`` with these endpoints:

- ``POST /ct-login`` — proxy login credentials to Control Tower
- ``POST /token-exchange`` — exchange an OAuth authorization code for tokens
- ``POST /refresh`` — rotate access/refresh tokens via CT
- ``POST /logout`` — clear auth cookies

The token-exchange route is mounted only when ``oauth_client_id`` is
configured. All endpoints set httpOnly cookies and NEVER log CT response
bodies.

Usage::

    from ct_auth.bff import create_bff_routes

    bff = create_bff_routes(ct_base_url="https://ct.example.com")
    app.include_router(bff.router, prefix="/api/auth")

    # On shutdown:
    await bff.close()
"""

from __future__ import annotations

import asyncio
import ipaddress
import logging
import os
import time
from collections import defaultdict, deque
from collections.abc import Awaitable, Callable
from typing import Any
from urllib.parse import urlparse

import httpx

try:
    from fastapi import APIRouter, Request, Response
    from fastapi.responses import JSONResponse
except ImportError as exc:
    raise ImportError(
        "FastAPI is required for ct_auth.bff. "
        "Install with: pip install ct-auth[fastapi]"
    ) from exc

_logger = logging.getLogger("ct_auth.bff")


# SEC-2: simple in-memory sliding-window rate limiter for the BFF auth
# endpoints. Dependency-free (no slowapi). Process-local; in a multi-worker
# uvicorn setup each worker has its own limiter, so the effective limit is
# rate * worker_count. That's acceptable as a defence-in-depth layer in
# front of CT's own rate limiter, not a replacement for it.
class _SlidingWindowRateLimiter:
    """Per-key sliding window. Caps memory by capping the key dict size."""

    def __init__(self, max_calls: int, window_seconds: float, max_keys: int = 5000) -> None:
        self.max_calls = max_calls
        self.window_seconds = window_seconds
        self.max_keys = max_keys
        self._buckets: dict[str, deque[float]] = defaultdict(deque)

    def is_allowed(self, key: str) -> bool:
        now = time.monotonic()
        bucket = self._buckets[key]
        # Drop entries older than the window
        cutoff = now - self.window_seconds
        while bucket and bucket[0] < cutoff:
            bucket.popleft()
        if len(bucket) >= self.max_calls:
            return False
        bucket.append(now)
        # Cap dict size by evicting oldest keys
        if len(self._buckets) > self.max_keys:
            for _ in range(len(self._buckets) - self.max_keys):
                self._buckets.pop(next(iter(self._buckets)))
        return True


def _client_key(request: Request) -> str:
    """Identify a request for rate-limiting purposes.

    Prefers the trusted forwarded IP if behind a known reverse proxy,
    falls back to the immediate peer address. Cookie-based fallback
    handles localhost dev where every request looks like 127.0.0.1.
    """
    fwd = request.headers.get("x-forwarded-for", "").split(",")[0].strip()
    if fwd:
        return f"ip:{fwd}"
    if request.client and request.client.host:
        return f"ip:{request.client.host}"
    # Fall back to a random session-ish marker so dev still rate-limits
    return f"unknown:{id(request)}"


# Limit token-exchange to 10 calls per minute per client IP. Real users
# trigger this once per OAuth flow, so 10/min is generous; brute-force
# attempts will hit the cap.
_TOKEN_EXCHANGE_LIMITER = _SlidingWindowRateLimiter(max_calls=10, window_seconds=60.0)


def _is_dev_env() -> bool:
    """Check if running in development or test environment.

    B-025: ``ENV=test`` inherits dev-mode leniency ONLY when the opt-in flag
    ``CT_AUTH_TEST_ALLOW_PRIVATE=true`` is set. This prevents a CI run that
    talks to a real CT instance from silently disabling the SSRF checks.
    """
    env = os.environ.get("ENV", "").strip().lower()
    if env == "development":
        return True
    if env == "test":
        return os.environ.get("CT_AUTH_TEST_ALLOW_PRIVATE", "").strip().lower() in (
            "1", "true", "yes", "on",
        )
    return False


# Metadata / cloud-credential addresses always denied regardless of ENV (B-002).
_METADATA_DENYLIST_HOSTS = frozenset({
    "169.254.169.254",      # AWS / Azure / GCP IMDS IPv4
    "fd00:ec2::254",        # AWS IMDS IPv6
    "metadata.google.internal",
    "metadata.goog",
    "metadata",
})

# Any input URL containing any of these control characters is rejected
# regardless of environment (B-009 log-injection prevention).
_URL_FORBIDDEN_CHARS = frozenset("\r\n\0\t\v\f")

# Max URL length accepted by _validate_ct_base_url / _validate_webhook_url.
# Prevents a malicious multi-MB env-var from stalling construction (B-033)
# and blocks whitespace-smuggled phishing URLs in email bodies (B-024).
_URL_MAX_LENGTH = 2048

# DNS-resolution timeout for _resolve_hostname_is_private (B-020). Longer
# than a fast-path resolve but short enough that a hostile DNS server cannot
# stall CTEndpointResolver.__init__ indefinitely at process boot.
_DNS_RESOLVE_TIMEOUT_SECONDS = 3.0


def _reject_url_control_characters(url: str, label: str) -> None:
    # B-033: length cap BEFORE per-char scan so a multi-MB URL fails fast.
    if len(url) > _URL_MAX_LENGTH:
        raise ValueError(
            f"{label} exceeds {_URL_MAX_LENGTH} char limit (got {len(url)})"
        )
    for ch in url:
        if ch in _URL_FORBIDDEN_CHARS:
            raise ValueError(
                f"{label} contains forbidden control character {ch!r}; "
                "URLs must be free of CR/LF/NUL/TAB to prevent log injection"
            )
    # B-024: reject URL characters that enable phishing smuggling in email
    # bodies (spaces inside URLs, angle-bracket HTML smuggling, quotes).
    for ch in '<>" ':
        if ch in url:
            raise ValueError(
                f"{label} contains forbidden character {ch!r}; URLs must not "
                "contain whitespace, quotes, or angle brackets"
            )


import threading as _threading  # noqa: E402


# A-303 / FIND-A-303 / B-039 / A-503: DNS resolution runs on a per-call
# daemon thread so an abandoned `socket.getaddrinfo` call cannot stall
# interpreter shutdown. Per-call threads are UNBOUNDED by default —
# under a hostile DNS server, repeated resolver construction would leak
# one FD per blocked thread and exhaust RLIMIT_NOFILE. Round 5 added a
# BoundedSemaphore cap that is ACQUIRED before creating the thread but
# NOT released when the thread is abandoned on timeout — so the permit
# count tracks leaked FDs, not live call count.
#
# A-503 (Round 6): a permit-not-released-on-timeout design by itself
# creates a permanent self-DoS — after N timeouts in process lifetime
# all subsequent DNS validation fails closed forever. Round 6 adds a
# **bounded reclaim window**: each acquired permit is tagged with a
# monotonic timestamp; when all permits are exhausted, the module
# sweeps for permits older than ``_DNS_LEAK_PERMIT_RECLAIM_SECONDS``
# (default 5 minutes) and returns them to the pool. This keeps the
# conservative fail-closed semantics under immediate hostile DNS while
# still allowing recovery under sustained normal use.
_DNS_LEAK_PERMIT_CAP = 4
_DNS_LEAK_PERMIT_RECLAIM_SECONDS = 300.0  # 5 minutes
_DNS_LEAK_PERMITS = _threading.BoundedSemaphore(_DNS_LEAK_PERMIT_CAP)
# Tracks the monotonic timestamp at which each currently-held permit
# was acquired. When a permit is released (successful resolve), its
# timestamp is removed. When the cap is exhausted and all pending
# timestamps are older than the reclaim window, they are refunded.
_DNS_LEAK_PERMIT_HOLD_TIMES: list[float] = []
_DNS_LEAK_PERMIT_LOCK = _threading.Lock()


class _DaemonThreadPoolExecutor:
    """Compatibility shim for existing tests / grep patterns.

    Not actually a ThreadPoolExecutor — just a sentinel class used to
    document that the DNS resolve path uses per-call daemon threads
    gated by a leaked-FD semaphore. See ``_resolve_hostname_is_private``
    for the actual implementation.
    """

    pass


_DNS_EXECUTOR_MARKER = _DaemonThreadPoolExecutor()


def _get_dns_executor() -> _DaemonThreadPoolExecutor:
    """Return a sentinel indicating the DNS resolve path is daemon-backed.

    Existed as a ThreadPoolExecutor in earlier rounds; kept as a
    compatibility accessor so older call sites and tests still import.
    """
    return _DNS_EXECUTOR_MARKER


def _resolve_hostname_is_private(hostname: str, *, is_dev: bool | None = None) -> bool:
    """Return True if the hostname resolves to ANY private/loopback/link-local addr.

    Best-effort DNS check at validation time (B-002). Runs on a per-call
    daemon thread with a 3-second hard cap (B-020). If the worker doesn't
    return in time, it is abandoned (daemon=True ensures interpreter
    shutdown is not blocked, A-303) and we fail closed in non-dev.

    **FD-leak protection (B-039):** a module-level BoundedSemaphore caps
    the number of simultaneously-leaked threads at
    ``_DNS_LEAK_PERMIT_CAP``. The permit is NOT released on timeout, so
    each abandoned thread consumes a permit for the lifetime of its
    leaked socket FD. When all permits are consumed, subsequent calls
    fail closed in non-dev without creating more threads.

    **TOCTOU (B-038):** accept an explicit ``is_dev`` parameter so the
    caller's env snapshot is used consistently for both the URL
    scheme/SSRF check and the DNS timeout fallback, avoiding an
    independent re-read of ``ENV`` from this function.

    Does NOT protect against DNS rebinding after validation — that
    requires runtime DNS pinning which is out of scope; the
    metadata-address denylist is the primary guard against the IMDS
    exfiltration class.
    """
    import socket

    if is_dev is None:
        is_dev = _is_dev_env()

    # B-039 + A-503: try to acquire a leak permit. If none available,
    # sweep for permits held longer than the reclaim window and refund
    # them (bounded reclaim). Then retry. If still exhausted, fail closed.
    permit_acquired = _DNS_LEAK_PERMITS.acquire(blocking=False)
    if not permit_acquired:
        now = time.monotonic()
        reclaimed = 0
        with _DNS_LEAK_PERMIT_LOCK:
            # Timestamps are kept sorted by acquire time (append-only).
            # Reclaim everything older than the window.
            while (
                _DNS_LEAK_PERMIT_HOLD_TIMES
                and (now - _DNS_LEAK_PERMIT_HOLD_TIMES[0]) > _DNS_LEAK_PERMIT_RECLAIM_SECONDS
            ):
                _DNS_LEAK_PERMIT_HOLD_TIMES.pop(0)
                try:
                    _DNS_LEAK_PERMITS.release()
                    reclaimed += 1
                except ValueError:
                    # BoundedSemaphore.release() raises ValueError if
                    # released beyond the initial value; treat as
                    # no-op and stop reclaiming.
                    break
        if reclaimed:
            _logger.info(
                "ct_auth.dns_resolve_permit_reclaimed count=%d window_s=%.0f — "
                "refunding permits held longer than the reclaim window",
                reclaimed,
                _DNS_LEAK_PERMIT_RECLAIM_SECONDS,
            )
            permit_acquired = _DNS_LEAK_PERMITS.acquire(blocking=False)
    if not permit_acquired:
        _logger.warning(
            "ct_auth.dns_resolve_leak_cap_exhausted hostname=%r cap=%d reclaim_s=%.0f — "
            "previous DNS calls have leaked threads and no permits are reclaimable; "
            "failing closed in non-dev",
            hostname,
            _DNS_LEAK_PERMIT_CAP,
            _DNS_LEAK_PERMIT_RECLAIM_SECONDS,
        )
        return not is_dev

    # Record the acquire time under the lock.
    acquire_time = time.monotonic()
    with _DNS_LEAK_PERMIT_LOCK:
        _DNS_LEAK_PERMIT_HOLD_TIMES.append(acquire_time)

    result: list[list[tuple]] = []
    done = _threading.Event()
    permit_released = False

    def _do_resolve() -> None:
        try:
            result.append(socket.getaddrinfo(hostname, None))
        except OSError:
            result.append([])
        finally:
            done.set()

    t = _threading.Thread(
        target=_do_resolve,
        name=f"ct-auth-dns-{hostname[:32]}",
        daemon=True,  # MUST be set before start()
    )
    t.start()
    try:
        if not done.wait(timeout=_DNS_RESOLVE_TIMEOUT_SECONDS):
            _logger.warning(
                "ct_auth.dns_resolve_timeout hostname=%r timeout=%.1fs — "
                "cannot verify private IP; failing closed in non-dev. "
                "Permit retained for the lifetime of the leaked thread.",
                hostname,
                _DNS_RESOLVE_TIMEOUT_SECONDS,
            )
            # INTENTIONAL: do NOT release the permit — the thread still
            # holds an FD. Abandoned + daemon ensures interpreter shutdown
            # is not blocked, but the permit count tracks live FD pressure.
            return not is_dev

        results = result[0] if result else []
        for family, _type, _proto, _canonname, sockaddr in results:
            ip = sockaddr[0]
            try:
                addr = ipaddress.ip_address(ip.split("%", 1)[0])
            except ValueError:
                continue
            if addr.is_private or addr.is_loopback or addr.is_link_local:
                return True
        return False
    finally:
        # B-039: only release the permit if the resolve completed (done.set()).
        # If we timed out, the permit stays consumed until the reclaim
        # window sweeps it back (A-503).
        if done.is_set() and not permit_released:
            with _DNS_LEAK_PERMIT_LOCK:
                try:
                    _DNS_LEAK_PERMIT_HOLD_TIMES.remove(acquire_time)
                except ValueError:
                    pass  # already reclaimed by the sweep path
            try:
                _DNS_LEAK_PERMITS.release()
            except ValueError:
                pass
            permit_released = True


def _validate_ct_base_url(url: str, label: str = "ct_base_url") -> str:
    """Validate and return a CT base URL.

    Raises ValueError if:
    - The URL contains any CR/LF/NUL/TAB (B-009).
    - The URL carries userinfo (B-019).
    - The scheme is not https in non-dev.
    - The hostname is an IP literal that is private/link-local/loopback in non-dev.
    - The hostname is a metadata/cloud-credential well-known name (always).
    - The hostname resolves to a private/link-local/loopback IP in non-dev (best-effort DNS).
    """
    _reject_url_control_characters(url, label)

    parsed = urlparse(url)
    is_dev = _is_dev_env()

    # Reject userinfo (B-019): `https://user:pass@host/...` is a credential-leak surface.
    if parsed.username or parsed.password:
        raise ValueError(
            f"{label} must not contain userinfo (user:pass@host); got {url!r}"
        )

    # Scheme check
    if parsed.scheme not in ("http", "https"):
        raise ValueError(
            f"{label} must use http:// or https:// (got {parsed.scheme!r})"
        )
    if parsed.scheme != "https" and not is_dev:
        raise ValueError(
            f"{label} must use https:// in non-development environments "
            f"(got {parsed.scheme}://)"
        )

    hostname_raw = (parsed.hostname or "").strip("[]")
    # Strip trailing dot so FQDN-with-dot cannot bypass same-origin / denylist (B-004).
    hostname = hostname_raw.rstrip(".").casefold()

    # Metadata well-known denylist — always, regardless of ENV.
    if hostname in _METADATA_DENYLIST_HOSTS:
        raise ValueError(
            f"{label} hostname is a cloud-metadata address and is always denied "
            f"({hostname!r})"
        )

    # SSRF protection: reject private/link-local/loopback IPs in non-dev.
    if not is_dev:
        try:
            addr = ipaddress.ip_address(hostname)
            if addr.is_private or addr.is_loopback or addr.is_link_local:
                raise ValueError(
                    f"{label} must not resolve to a private/link-local/loopback "
                    f"address in non-development environments (got {hostname!r})"
                )
        except ValueError as e:
            if "private" in str(e) or "link-local" in str(e) or "loopback" in str(e):
                raise
            # Hostname (not an IP literal) — best-effort DNS check (B-002).
            # B-041 / A-502: pass the caller's is_dev snapshot explicitly so
            # the helper does not re-read ENV (TOCTOU closure).
            if hostname and _resolve_hostname_is_private(hostname, is_dev=is_dev):
                raise ValueError(
                    f"{label} hostname {hostname!r} resolves to a "
                    "private/link-local/loopback address; rejected in non-dev"
                )

    return url.rstrip("/")


def _emit_multiworker_warning_if_needed() -> None:
    """FIND-C-008 / plan AC-2.30 / A3-004 — warn when running `--workers >= 4`
    without Redis dedup and the operator hasn't silenced the warning.
    """
    try:
        expected_workers = int(os.environ.get("CT_FALLBACK_EXPECTED_WORKERS", "2"))
    except ValueError:
        expected_workers = 2
    redis_url = os.environ.get("CT_FALLBACK_DEDUP_REDIS_URL", "").strip()
    warn_enabled = os.environ.get("CT_FALLBACK_DEDUP_WARN", "on").lower() != "off"
    if expected_workers >= 4 and not redis_url and warn_enabled:
        _logger.warning(
            "ct_auth.fallback_dedup_multiworker_no_redis expected_workers=%d — "
            "each worker will fire its own notification. "
            "Set CT_FALLBACK_DEDUP_REDIS_URL or CT_FALLBACK_DEDUP_WARN=off to silence.",
            expected_workers,
        )


class BFFRoutes:
    """Container for BFF auth routes and their httpx client lifecycle.

    Attributes:
        router: FastAPI APIRouter with auth BFF endpoints.
    """

    def __init__(
        self,
        router: APIRouter,
        http_client: httpx.AsyncClient | None,
        owns_client: bool,
        lock: asyncio.Lock,
        jwks_client: Any | None = None,
        resolver: Any | None = None,
        primary_base_url: str = "",
    ) -> None:
        self.router = router
        self._http_client = http_client
        self._owns_client = owns_client
        self._lock = lock
        self._jwks_client = jwks_client
        self._resolver = resolver
        self._primary_base_url = primary_base_url
        self._resolver_started = False
        self._resolver_start_lock = asyncio.Lock()
        self._lazy_autostart_warned = False

    async def start(self) -> None:
        """Start the resolver's background task if one is present (AC-2.20).

        Idempotent. Apps should call ``await bff.start()`` from their FastAPI
        lifespan startup hook so the resolver's health-check loop runs for the
        lifetime of the process.
        """
        if self._resolver is None or self._resolver_started:
            return
        async with self._resolver_start_lock:
            if not self._resolver_started:
                await self._resolver.start()
                self._resolver_started = True

    async def _active_base_url(self) -> str:
        """Return the currently-active CT base URL, ensuring the resolver runs.

        Called at REQUEST time by every route handler so that failover
        propagates to outbound CT calls (AC-2.19). Raises
        ``ct_auth.resolver.CTBothDownError`` when both primary and fallback
        have failed their health checks. Any unexpected exception is masked
        as CTBothDownError so route handlers have a stable 503 contract
        (A-208), BUT the masked exception is logged at ERROR level with a
        short correlation token so operators can still pin it down (A-301).
        """
        if self._resolver is None:
            return self._primary_base_url
        if not self._resolver_started:
            # A-207: lazy autostart is defence-in-depth, but it masks missing
            # lifespan wiring. Warn once so operators can fix the wiring.
            if not self._lazy_autostart_warned:
                self._lazy_autostart_warned = True
                _logger.warning(
                    "ct_auth.bff.resolver_lazy_autostart — start() was not called "
                    "from the FastAPI lifespan; falling back to lazy start on first "
                    "request. Add 'await bff.start()' to your lifespan startup hook "
                    "to avoid paying cold-start latency on the first request."
                )
            await self.start()
        from ct_auth.resolver import CTBothDownError
        try:
            return self._resolver.active_base_url()
        except CTBothDownError:
            raise
        except Exception as exc:  # noqa: BLE001
            # A-301: correlation token so the ERROR log line can be tied
            # back to the specific 503 response downstream. Short-form
            # UUID prefix keeps the log compact.
            import uuid as _uuid

            correlation = _uuid.uuid4().hex[:12]
            _logger.error(
                "ct_auth.bff.resolver_active_base_url_unexpected_error "
                "correlation=%s exc_class=%s exc=%r",
                correlation,
                type(exc).__name__,
                exc,
                exc_info=True,
            )
            raise CTBothDownError(
                f"unexpected resolver fault ({type(exc).__name__}; "
                f"correlation={correlation})"
            ) from exc

    async def _get_client(self) -> httpx.AsyncClient:
        """Get or lazily create the httpx client with lock protection."""
        if self._http_client is not None and not getattr(
            self._http_client, "is_closed", False
        ):
            return self._http_client

        async with self._lock:
            # Double-check after acquiring lock
            if self._http_client is not None and not getattr(
                self._http_client, "is_closed", False
            ):
                return self._http_client

            self._http_client = httpx.AsyncClient(
                timeout=10.0,
                limits=httpx.Limits(
                    max_connections=20, max_keepalive_connections=10
                ),
            )
            self._owns_client = True
            return self._http_client

    async def close(self) -> None:
        """Close the httpx client, cancel the resolver, close the jwks client. Call in app lifespan.

        Close order (per D-019): resolver -> jwks client -> bff http client.
        """
        # AC-2.20: cancel resolver background task first
        if self._resolver is not None:
            try:
                await self._resolver.close()
            except Exception:  # noqa: BLE001
                _logger.debug("resolver close raised", exc_info=True)
            self._resolver = None

        # Close any closable jwks client (A-016)
        if self._jwks_client is not None:
            close_fn = getattr(self._jwks_client, "close", None)
            if callable(close_fn):
                try:
                    result = close_fn()
                    if asyncio.iscoroutine(result):
                        await result
                except Exception:  # noqa: BLE001
                    _logger.debug("jwks_client close raised", exc_info=True)
            self._jwks_client = None

        if self._owns_client and self._http_client is not None:
            if not getattr(self._http_client, "is_closed", False):
                await self._http_client.aclose()
            self._http_client = None


def create_bff_routes(
    ct_base_url: str,
    *,
    cookie_name: str = "access_token",
    refresh_cookie_name: str = "refresh_token",
    cookie_path: str = "/api",
    refresh_cookie_path: str = "/api/auth",
    access_token_max_age: int = 900,
    refresh_token_max_age: int = 604_800,
    secure_cookies: bool | None = None,
    cookie_samesite: str = "lax",
    login_path: str = "/ct-login",
    token_exchange_path: str = "/token-exchange",
    refresh_path: str = "/refresh",
    logout_path: str = "/logout",
    oauth_client_id: str | None = None,
    http_client: httpx.AsyncClient | None = None,
    on_refresh: Callable[[dict[str, Any]], Awaitable[None]] | None = None,
    include_me: bool = False,
    jwks_url: str | None = None,
    # WP-SCC-2 AC-2.18 fallback resolver wiring (opt-in via ct_fallback_base_url)
    ct_fallback_base_url: str | None = None,
    ct_fallback_jwks_url: str | None = None,
    healthcheck_interval_seconds: float = 30.0,
    failure_threshold: int = 3,
    recovery_threshold: int = 2,
    notifier: Any | None = None,
) -> BFFRoutes:
    """Create BFF auth routes that proxy to Control Tower.

    Args:
        ct_base_url: Base URL of the Control Tower instance.
        cookie_name: Name for the access token cookie.
        refresh_cookie_name: Name for the refresh token cookie.
        cookie_path: Path scope for the access token cookie.
        refresh_cookie_path: Path scope for the refresh token cookie.
        access_token_max_age: Max age in seconds for the access token cookie.
        refresh_token_max_age: Max age in seconds for the refresh token cookie.
        secure_cookies: Whether to set Secure flag. None = auto-detect from ENV.
        cookie_samesite: SameSite attribute for cookies.
        login_path: Route path for the login endpoint.
        token_exchange_path: Route path for the OAuth code exchange endpoint.
        refresh_path: Route path for the refresh endpoint.
        logout_path: Route path for the logout endpoint.
        oauth_client_id: OAuth client identifier used when exchanging
            authorization codes. When omitted, the token exchange route is not
            mounted.
        http_client: Optional pre-configured httpx.AsyncClient.
        on_refresh: Optional async callback invoked after a successful token
            refresh. Receives the ``user`` dict from CT's refresh response::

                {
                    "id": "user-uuid",
                    "email": "user@example.com",
                    "display_name": "Jane Smith",
                    "org_ids": ["org-uuid"],
                    "roles": ["editor"],
                }

            This is the CT user object, NOT decoded JWT claims. Use it for
            audit logging (e.g., ``data.get("id")``). Exceptions in the
            callback are caught and logged — they never break the refresh.
        include_me: When True, mount a GET /me endpoint that returns JWT
            claims from the access_token cookie. Requires jwks_url.
        jwks_url: JWKS endpoint URL, required when include_me=True.

    Returns:
        BFFRoutes with .router and .close().

    Raises:
        ValueError: If ct_base_url fails validation (http in prod, private IP).
        ValueError: If include_me=True but jwks_url is not provided.
    """
    # Validate URL once at factory time — frozen after init
    base_url = _validate_ct_base_url(ct_base_url, label="ct_base_url")

    if include_me and not jwks_url:
        raise ValueError("jwks_url is required when include_me=True")

    # WP-SCC-2 AC-2.18, AC-2.19: optional CTEndpointResolver wiring.
    resolver_instance: Any | None = None
    if ct_fallback_base_url:
        # Deferred import to avoid circular with ct_auth.resolver (which imports
        # _validate_ct_base_url from this module).
        from ct_auth.resolver import (
            CTEndpointResolver,
            CompositeNotifier,
            NoopNotifier,
        )
        from ct_auth.notifiers import (
            EmailNotifier,
            WebhookNotifier,
            _build_notifier_from_env,
        )

        # Auto-wrap raw notifiers in a CompositeNotifier so dedup / timeout /
        # idempotence apply uniformly (FIND-A-011). If the caller passes
        # `notifier=None`, bootstrap one from env vars: CT_FALLBACK_NOTIFY_EMAIL
        # and CT_FALLBACK_NOTIFY_WEBHOOK (FIND-A-006).
        if notifier is None:
            notifier = _build_notifier_from_env(
                primary_url=ct_base_url,
                fallback_url=ct_fallback_base_url,
            )
        if notifier is not None and not isinstance(notifier, CompositeNotifier):
            notifier = CompositeNotifier([notifier])

        resolver_instance = CTEndpointResolver(
            primary_url=ct_base_url,
            fallback_url=ct_fallback_base_url,
            health_check_interval_seconds=healthcheck_interval_seconds,
            failure_threshold=failure_threshold,
            recovery_threshold=recovery_threshold,
            notifier=notifier or NoopNotifier(),
        )

        # Multi-worker Redis-dedup warning (FIND-C-008).
        _emit_multiworker_warning_if_needed()

    # Resolve secure_cookies from environment if not explicitly set
    if secure_cookies is None:
        secure_cookies = not _is_dev_env()

    # Set up JWKS client for /me endpoint if needed. When a resolver is wired,
    # prefer StatefulJWKSClient so `/me` follows failover (FIND-A-003 / AC-2.19).
    jwks_client: Any = None
    if include_me and jwks_url:
        if resolver_instance is not None:
            from ct_auth.stateful_jwks import StatefulJWKSClient

            jwks_client = StatefulJWKSClient(resolver=resolver_instance)
        else:
            from ct_auth.jwks import JWKSClient

            jwks_client = JWKSClient(jwks_url=jwks_url)

    lock = asyncio.Lock()
    owns_client = http_client is None

    bff = BFFRoutes(
        router=APIRouter(),
        http_client=http_client,
        owns_client=owns_client,
        lock=lock,
        jwks_client=jwks_client,
        resolver=resolver_instance,
        primary_base_url=base_url,
    )

    router = bff.router

    # FIND-A-002 / C-001: every outbound CT call must read the active URL from
    # the resolver at REQUEST time. This helper returns a JSONResponse(503)
    # when CTBothDownError fires — callers short-circuit on that.
    async def _get_target_base_url() -> str:
        return await bff._active_base_url()

    # Imported lazily to avoid the cycle with ct_auth.resolver (which imports
    # _validate_ct_base_url from this module). Only referenced inside the
    # route handlers.
    if resolver_instance is not None:
        from ct_auth.resolver import CTBothDownError as _CTBothDownError
    else:
        class _CTBothDownError(RuntimeError):  # type: ignore[no-redef]
            """Sentinel placeholder used when no resolver is wired."""

    def _both_down_response() -> JSONResponse:
        return JSONResponse(
            status_code=503,
            content={"detail": "Both CT instances are unreachable"},
        )

    def _set_auth_cookies(
        response: Response,
        access_token: str,
        refresh_token: str,
    ) -> None:
        """Set both auth cookies on the response."""
        response.set_cookie(
            key=cookie_name,
            value=access_token,
            max_age=access_token_max_age,
            path=cookie_path,
            httponly=True,
            secure=secure_cookies,
            samesite=cookie_samesite,
        )
        response.set_cookie(
            key=refresh_cookie_name,
            value=refresh_token,
            max_age=refresh_token_max_age,
            path=refresh_cookie_path,
            httponly=True,
            secure=secure_cookies,
            samesite=cookie_samesite,
        )

    def _clear_auth_cookies(response: Response) -> None:
        """Delete both auth cookies from the response."""
        response.delete_cookie(
            key=cookie_name,
            path=cookie_path,
            httponly=True,
            secure=secure_cookies,
            samesite=cookie_samesite,
        )
        response.delete_cookie(
            key=refresh_cookie_name,
            path=refresh_cookie_path,
            httponly=True,
            secure=secure_cookies,
            samesite=cookie_samesite,
        )

    def _extract_ct_error_message(response: httpx.Response, default: str) -> str:
        """Extract a safe error message from a CT JSON response."""
        try:
            body = response.json()
        except ValueError:
            return default

        if isinstance(body, dict):
            detail = body.get("detail")
            if isinstance(detail, dict):
                message = detail.get("message")
                if isinstance(message, str) and message:
                    return message

            for key in ("message", "detail"):
                value = body.get(key)
                if isinstance(value, str) and value:
                    return value

        return default

    proxy_headers = {"X-Requested-With": "XMLHttpRequest"}

    @router.post(login_path)
    async def ct_login(request: Request) -> Response:
        """Proxy login credentials to Control Tower and set auth cookies."""
        client = await bff._get_client()
        body = await request.json()

        try:
            target_base = await _get_target_base_url()
        except _CTBothDownError:
            _logger.warning("bff_login: both_ct_down status=503")
            return _both_down_response()

        try:
            ct_resp = await client.post(
                f"{target_base}/api/v1/auth/login",
                json=body,
                headers=proxy_headers,
            )
        except (httpx.ConnectError, httpx.ConnectTimeout, httpx.TimeoutException):
            _logger.warning("bff_login: connection_failed status=502")
            return JSONResponse(
                status_code=502,
                content={"detail": "Authentication service unavailable"},
            )

        # Log only action + status — NEVER the response body (AC-61)
        _logger.info("bff_login: ct_responded status=%d", ct_resp.status_code)

        if ct_resp.status_code == 401:
            return JSONResponse(
                status_code=401,
                content={"detail": "Invalid credentials"},
            )

        if ct_resp.status_code == 429:
            return JSONResponse(
                status_code=429,
                content={"detail": "Too many requests"},
            )

        if ct_resp.status_code >= 500:
            _logger.warning("bff_login: ct_server_error status=%d", ct_resp.status_code)
            return JSONResponse(
                status_code=502,
                content={"detail": "Authentication service unavailable"},
            )

        if ct_resp.status_code != 200:
            _logger.warning(
                "bff_login: unexpected_status status=%d", ct_resp.status_code
            )
            return JSONResponse(
                status_code=502,
                content={"detail": "Authentication service unavailable"},
            )

        ct_data: dict[str, Any] = ct_resp.json()

        access_token = ct_data.get("access_token", "")
        refresh_token = ct_data.get("refresh_token", "")

        # Build response with user info only (no tokens in body)
        response_body: dict[str, Any] = {}
        if "user" in ct_data:
            response_body["user"] = ct_data["user"]

        response = JSONResponse(status_code=200, content=response_body)
        _set_auth_cookies(response, access_token, refresh_token)
        return response

    if oauth_client_id:
        @router.post(token_exchange_path)
        async def ct_token_exchange(request: Request) -> Response:
            """Exchange an OAuth authorization code and set auth cookies."""
            # SEC-2: per-IP rate limit (10/minute) BEFORE we touch CT.
            # Brute-force code enumeration would otherwise be a free
            # amplification attack against CT's own rate limiter.
            client_key = _client_key(request)
            if not _TOKEN_EXCHANGE_LIMITER.is_allowed(client_key):
                _logger.warning(
                    "bff_token_exchange: rate_limited client_key=%s client_id=%s",
                    client_key,
                    oauth_client_id,
                )
                return JSONResponse(
                    status_code=429,
                    content={"detail": "Too many token exchange attempts. Try again in a minute."},
                    headers={"Retry-After": "60"},
                )
            try:
                body = await request.json()
            except Exception:
                return JSONResponse(
                    status_code=400,
                    content={"detail": "Invalid JSON body"},
                )

            code = str(body.get("code", "")).strip()
            redirect_uri = str(body.get("redirect_uri", "")).strip()
            if not code or not redirect_uri:
                return JSONResponse(
                    status_code=400,
                    content={"detail": "code and redirect_uri are required"},
                )

            client = await bff._get_client()

            try:
                target_base = await _get_target_base_url()
            except _CTBothDownError:
                _logger.warning(
                    "bff_token_exchange: both_ct_down status=503 client_id=%s",
                    oauth_client_id,
                )
                return _both_down_response()

            try:
                ct_resp = await client.post(
                    f"{target_base}/api/v1/auth/token",
                    json={
                        "grant_type": "authorization_code",
                        "code": code,
                        "redirect_uri": redirect_uri,
                        "client_id": oauth_client_id,
                    },
                    headers=proxy_headers,
                )
            except (httpx.ConnectError, httpx.ConnectTimeout, httpx.TimeoutException):
                _logger.warning(
                    "bff_token_exchange: connection_failed status=502 client_id=%s",
                    oauth_client_id,
                )
                return JSONResponse(
                    status_code=502,
                    content={"detail": "Authentication service unavailable"},
                )

            _logger.info(
                "bff_token_exchange: ct_responded status=%d client_id=%s",
                ct_resp.status_code,
                oauth_client_id,
            )

            if ct_resp.status_code in (400, 401, 403):
                return JSONResponse(
                    status_code=ct_resp.status_code,
                    content={
                        "detail": _extract_ct_error_message(
                            ct_resp,
                            "Token exchange failed",
                        )
                    },
                )

            if ct_resp.status_code == 429:
                return JSONResponse(
                    status_code=429,
                    content={"detail": "Too many requests"},
                )

            if ct_resp.status_code >= 500:
                _logger.warning(
                    "bff_token_exchange: ct_server_error status=%d client_id=%s",
                    ct_resp.status_code,
                    oauth_client_id,
                )
                return JSONResponse(
                    status_code=502,
                    content={"detail": "Authentication service unavailable"},
                )

            if ct_resp.status_code != 200:
                _logger.warning(
                    "bff_token_exchange: unexpected_status status=%d client_id=%s",
                    ct_resp.status_code,
                    oauth_client_id,
                )
                return JSONResponse(
                    status_code=502,
                    content={"detail": "Authentication service unavailable"},
                )

            ct_data: dict[str, Any] = ct_resp.json()
            access_token = ct_data.get("access_token", "")
            refresh_token = ct_data.get("refresh_token", "")

            response = JSONResponse(
                status_code=200,
                content={"status": "authenticated"},
            )
            _set_auth_cookies(response, access_token, refresh_token)
            return response

    @router.post(refresh_path)
    async def ct_refresh(request: Request) -> Response:
        """Read refresh_token cookie and forward to CT for rotation."""
        refresh_token = request.cookies.get(refresh_cookie_name)
        if not refresh_token:
            _logger.info("bff_refresh: no_cookie status=401")
            return JSONResponse(
                status_code=401,
                content={"detail": "No refresh token"},
            )

        client = await bff._get_client()

        try:
            target_base = await _get_target_base_url()
        except _CTBothDownError:
            _logger.warning("bff_refresh: both_ct_down status=503")
            return _both_down_response()

        try:
            ct_resp = await client.post(
                f"{target_base}/api/v1/auth/refresh",
                cookies={refresh_cookie_name: refresh_token},
                headers=proxy_headers,
            )
        except (httpx.ConnectError, httpx.ConnectTimeout, httpx.TimeoutException):
            _logger.warning("bff_refresh: connection_failed status=502")
            return JSONResponse(
                status_code=502,
                content={"detail": "Authentication service unavailable"},
            )

        _logger.info("bff_refresh: ct_responded status=%d", ct_resp.status_code)

        if ct_resp.status_code != 200:
            # Refresh failed — clear cookies
            response = JSONResponse(
                status_code=401,
                content={"detail": "Refresh failed"},
            )
            _clear_auth_cookies(response)
            return response

        ct_data: dict[str, Any] = ct_resp.json()

        new_access = ct_data.get("access_token", "")
        new_refresh = ct_data.get("refresh_token", "")

        response_body: dict[str, Any] = {"status": "refreshed"}
        if "user" in ct_data:
            response_body["user"] = ct_data["user"]

        response = JSONResponse(status_code=200, content=response_body)
        _set_auth_cookies(response, new_access, new_refresh)

        # CT-SDK-008: invoke on_refresh callback if provided
        if on_refresh is not None:
            try:
                # Extract claims from the new access token for the callback
                callback_data = ct_data.get("user", {})
                await on_refresh(callback_data)
            except Exception:
                _logger.warning(
                    "bff_refresh: on_refresh callback failed", exc_info=True
                )

        return response

    @router.post(logout_path)
    async def ct_logout(request: Request) -> Response:
        """Clear auth cookies and return logged-out status."""
        _logger.info("bff_logout: clearing_cookies")
        response = JSONResponse(
            status_code=200,
            content={"status": "logged_out"},
        )
        _clear_auth_cookies(response)
        return response

    # CT-SDK-011: optional /me endpoint
    if include_me and jwks_client is not None:
        @router.get("/me")
        async def ct_me(request: Request) -> Response:
            """Return JWT claims from the access_token cookie."""
            token = request.cookies.get(cookie_name)
            if not token:
                return JSONResponse(
                    status_code=401,
                    content={"detail": "Not authenticated"},
                )

            try:
                from ct_auth.validator import decode_token_unverified, validate_token

                decoded = decode_token_unverified(token)
                kid = decoded["header"].get("kid")
                public_key = await jwks_client.get_public_key(kid)
                claims = validate_token(token, public_key)
            except Exception:
                _logger.debug("bff_me: token validation failed", exc_info=True)
                return JSONResponse(
                    status_code=401,
                    content={"detail": "Invalid or expired token"},
                )

            return JSONResponse(status_code=200, content=claims)

    return bff

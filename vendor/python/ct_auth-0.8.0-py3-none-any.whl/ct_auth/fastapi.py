"""FastAPI integration for Control Tower auth.

Install with the ``fastapi`` extra::

    pip install ct-auth[fastapi]

Usage::

    from ct_auth.fastapi import ControlTowerAuth, require_role, RequireServiceScope

    ct_auth = ControlTowerAuth(jwks_url="https://ct.example.com/api/v1/.well-known/jwks.json")

    @app.get("/protected")
    async def protected(claims: dict = Depends(ct_auth)):
        return {"user": claims["sub"]}

    @app.get("/admin")
    async def admin(claims: dict = Depends(require_role("admin"))):
        return {"admin": True}

    # S2S scope checking
    require_vault_read = RequireServiceScope("vault:credentials:read", ct_base_url="https://ct.example.com")

    @app.get("/internal")
    async def internal(sa_info: dict = Depends(require_vault_read)):
        return {"org_id": sa_info["org_id"]}
"""

from __future__ import annotations

import hashlib
import logging
import os
import time
from collections import OrderedDict
from typing import Any, Callable

import httpx

from ct_auth.jwks import JWKSClient
from ct_auth.permissions import has_app_permission as _has_app_perm
from ct_auth.permissions import has_role as _has_role
from ct_auth.validator import decode_token_unverified, validate_token

try:
    from fastapi import Depends, HTTPException, Request, status
except ImportError as exc:
    raise ImportError(
        "FastAPI is required for ct_auth.fastapi. "
        "Install with: pip install ct-auth[fastapi]"
    ) from exc

_logger = logging.getLogger("ct_auth.fastapi")


class ControlTowerAuth:
    """FastAPI dependency that extracts and validates a Control Tower JWT.

    Reads the token from the ``Authorization: Bearer <token>`` header
    or from the ``access_token`` cookie.

    Returns the decoded claims dict on success.

    Raises:
        HTTPException(401): If no token is present or validation fails.
    """

    def __init__(
        self,
        jwks_url: str,
        cache_ttl: int = 3600,
        audience: str | None = None,
    ) -> None:
        self._jwks = JWKSClient(jwks_url=jwks_url, cache_ttl=cache_ttl)
        self._audience = audience
        if audience is None:
            import logging
            logging.getLogger("ct_auth").warning(
                "No audience configured — tokens for any CT app will be accepted. "
                "Set audience='your-app-id' for proper isolation."
            )

    async def __call__(self, request: Request) -> dict[str, Any]:
        token = self._extract_token(request)
        if not token:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail={"error": "not_authenticated", "message": "Authentication required"},
            )

        try:
            decoded = decode_token_unverified(token)
            kid = decoded["header"].get("kid")
            public_key = await self._jwks.get_public_key(kid)
            claims = validate_token(token, public_key, audience=self._audience)
        except Exception:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail={"error": "invalid_token", "message": "Invalid or expired token"},
            )

        # CT-SDK-012: reject dev/test tokens in non-development environments
        if self._is_dev_token(claims) and not self._is_dev_env():
            _logger.warning("dev_token_rejected: sub=%s in non-dev environment", claims.get("sub"))
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail={"error": "invalid_token", "message": "Dev tokens not allowed in this environment"},
            )

        return claims

    async def validate_token_safe(self, token: str) -> dict[str, Any] | None:
        """Validate a token and return claims, or None on any failure.

        Unlike ``__call__``, this method never raises exceptions.
        Validation failures are logged at debug level.

        Args:
            token: The raw JWT string.

        Returns:
            Decoded claims dict on success, or ``None`` on any validation failure.
        """
        try:
            decoded = decode_token_unverified(token)
            kid = decoded["header"].get("kid")
            public_key = await self._jwks.get_public_key(kid)
            claims = validate_token(token, public_key, audience=self._audience)
            # Apply dev-token rejection (HIGH-2: match __call__ behaviour)
            if self._is_dev_token(claims) and not self._is_dev_env():
                _logger.debug("validate_token_safe: dev token rejected in non-dev env")
                return None
            return claims
        except Exception:
            _logger.debug("validate_token_safe: token validation failed", exc_info=True)
            return None

    def validate_token_safe_sync(self, token: str) -> dict[str, Any] | None:
        """Synchronous version of :meth:`validate_token_safe`.

        For use in synchronous middleware, CLI tools, or background workers
        where ``await`` is not available. Uses :meth:`JWKSClient.get_public_key_sync`
        internally.

        Args:
            token: The raw JWT string.

        Returns:
            Decoded claims dict on success, or ``None`` on any validation failure.
        """
        try:
            decoded = decode_token_unverified(token)
            kid = decoded["header"].get("kid")
            public_key = self._jwks.get_public_key_sync(kid)
            claims = validate_token(token, public_key, audience=self._audience)
            if self._is_dev_token(claims) and not self._is_dev_env():
                _logger.debug("validate_token_safe_sync: dev token rejected in non-dev env")
                return None
            return claims
        except Exception:
            _logger.debug("validate_token_safe_sync: token validation failed", exc_info=True)
            return None

    @staticmethod
    def _is_dev_token(claims: dict[str, Any]) -> bool:
        """Check if token is a known dev/test token."""
        dev_subjects = {"dev-token", "test-token", "dev", "test"}
        if claims.get("sub") in dev_subjects:
            return True
        if claims.get("dev_token") is True:
            return True
        return False

    @staticmethod
    def _is_dev_env() -> bool:
        """Check if running in development or test environment."""
        return os.environ.get("ENV", "").lower() in ("development", "test")

    @staticmethod
    def _extract_token(request: Request) -> str | None:
        """Extract JWT from Authorization header or cookie (Bearer first)."""
        auth_header = request.headers.get("Authorization")
        if auth_header and auth_header.lower().startswith("bearer "):
            return auth_header[7:]

        token = request.cookies.get("access_token")
        if token:
            return token

        return None


def require_role(
    role: str,
    org_id: str | None = None,
    *,
    jwks_url: str | None = None,
    _ct_auth: ControlTowerAuth | None = None,
) -> Callable[..., Any]:
    """Dependency factory that requires a specific role.

    You must supply either *jwks_url* (to create a new auth instance)
    or *_ct_auth* (to reuse an existing one).

    Usage::

        ct_auth = ControlTowerAuth(jwks_url="...")

        @app.get("/admin")
        async def admin(claims=Depends(require_role("admin", _ct_auth=ct_auth))):
            ...
    """
    if _ct_auth is None:
        if jwks_url is None:
            raise ValueError("Either jwks_url or _ct_auth must be provided")
        _ct_auth = ControlTowerAuth(jwks_url)

    auth_dep = _ct_auth

    async def _check(claims: dict[str, Any] = Depends(auth_dep)) -> dict[str, Any]:
        if not _has_role(claims, role, org_id):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail={"error": "forbidden", "message": f"Role '{role}' required"},
            )
        return claims

    return _check


def require_app_permission(
    app_id: str,
    permission: str,
    *,
    jwks_url: str | None = None,
    _ct_auth: ControlTowerAuth | None = None,
) -> Callable[..., Any]:
    """Dependency factory that requires a specific app permission.

    Usage::

        ct_auth = ControlTowerAuth(jwks_url="...")

        @app.get("/fla/write")
        async def fla_write(claims=Depends(require_app_permission("fla", "write", _ct_auth=ct_auth))):
            ...
    """
    if _ct_auth is None:
        if jwks_url is None:
            raise ValueError("Either jwks_url or _ct_auth must be provided")
        _ct_auth = ControlTowerAuth(jwks_url)

    auth_dep = _ct_auth

    async def _check(claims: dict[str, Any] = Depends(auth_dep)) -> dict[str, Any]:
        if not _has_app_perm(claims, app_id, permission):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail={
                    "error": "forbidden",
                    "message": f"App permission '{app_id}:{permission}' required",
                },
            )
        return claims

    return _check


# ── S2S Scope Checking ────────────────────────────────────────


class _LRUCache:
    """Thread-safe LRU cache with TTL for RequireServiceScope."""

    def __init__(self, max_size: int = 1000, ttl: float = 300.0) -> None:
        import threading
        self._max_size = max_size
        self._ttl = ttl
        self._cache: OrderedDict[str, tuple[float, dict[str, Any]]] = OrderedDict()
        self._lock = threading.Lock()

    def get(self, key: str) -> dict[str, Any] | None:
        with self._lock:
            entry = self._cache.get(key)
            if entry is None:
                return None
            timestamp, value = entry
            if time.time() - timestamp > self._ttl:
                del self._cache[key]
                return None
            self._cache.move_to_end(key)
            return value

    def put(self, key: str, value: dict[str, Any]) -> None:
        with self._lock:
            self._cache[key] = (time.time(), value)
            self._cache.move_to_end(key)
            while len(self._cache) > self._max_size:
                self._cache.popitem(last=False)


class RequireServiceScope:
    """FastAPI dependency that validates inbound S2S calls via X-API-Key.

    Extracts X-API-Key, calls /me on Control Tower, checks the required scope.
    Results are cached by SHA-256(key) with a 300s TTL and 1000-entry LRU.

    The ``*`` wildcard scope on a service account passes all checks.
    Error responses don't leak which scopes were expected.

    Usage::

        require_vault_read = RequireServiceScope(
            "vault:credentials:read",
            ct_base_url="https://ct.example.com",
        )

        @app.get("/credentials")
        async def list_creds(sa_info=Depends(require_vault_read)):
            ...
    """

    def __init__(
        self,
        required_scope: str,
        ct_base_url: str,
        cache_ttl: float = 300.0,
        cache_max_size: int = 1000,
    ) -> None:
        self._required_scope = required_scope
        self._base_url = ct_base_url.rstrip("/")
        self._cache_max_size = cache_max_size
        self._cache_ttl = cache_ttl
        self._cache = _LRUCache(max_size=cache_max_size, ttl=cache_ttl)
        self._http_client: httpx.AsyncClient | None = None
        from urllib.parse import urlparse
        parsed = urlparse(ct_base_url)
        is_local = parsed.hostname in ("localhost", "127.0.0.1", "::1")
        if parsed.scheme != "https" and not is_local:
            _logger.warning("ct_base_url is not HTTPS — API keys will be sent in cleartext")

    def _get_http_client(self) -> httpx.AsyncClient:
        """Lazy-create a long-lived HTTP client (avoids per-request connection setup).

        Call ``close()`` on application shutdown to release connections.
        """
        if self._http_client is None or self._http_client.is_closed:
            self._http_client = httpx.AsyncClient(
                timeout=10.0,
                limits=httpx.Limits(max_connections=20, max_keepalive_connections=10),
            )
        return self._http_client

    async def close(self) -> None:
        """Close the HTTP client. Call on application shutdown."""
        if self._http_client and not self._http_client.is_closed:
            await self._http_client.aclose()
            self._http_client = None

    def clear_cache(self) -> None:
        """Clear the SA info cache (emergency invalidation)."""
        self._cache = _LRUCache(max_size=self._cache_max_size, ttl=self._cache_ttl)

    async def __call__(self, request: Request) -> dict[str, Any]:
        api_key = request.headers.get("X-API-Key")
        if not api_key:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail={"error": "not_authenticated", "message": "X-API-Key header required"},
            )

        # Cache lookup by hashed key
        cache_key = hashlib.sha256(api_key.encode()).hexdigest()
        sa_info = self._cache.get(cache_key)

        if sa_info is None:
            # Call /me to validate and get SA info
            try:
                from datetime import datetime
                from datetime import timezone as _tz
                client = self._get_http_client()
                resp = await client.get(
                    f"{self._base_url}/api/v1/service-accounts/me",
                    headers={
                        "X-API-Key": api_key,
                        "X-CT-Timestamp": datetime.now(_tz.utc).isoformat(),
                    },
                )
                if resp.status_code != 200:
                    raise HTTPException(
                        status_code=status.HTTP_401_UNAUTHORIZED,
                        detail={"error": "invalid_key", "message": "Invalid or expired API key"},
                    )
                sa_info = resp.json()
                self._cache.put(cache_key, sa_info)
            except HTTPException:
                raise
            except Exception:
                _logger.exception("Failed to validate API key via /me")
                raise HTTPException(
                    status_code=status.HTTP_502_BAD_GATEWAY,
                    detail={"error": "upstream_error", "message": "Failed to validate API key"},
                )

        # Check scope
        scopes = sa_info.get("scopes") or []
        if self._required_scope not in scopes and "*" not in scopes:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail={"error": "forbidden", "message": "Insufficient scope"},
            )

        return sa_info


# ── Vault Credential Dependency ──────────────────────────────


# Module-level vault client cache (singleton per config)
_vault_clients: dict[tuple[str, str, str], Any] = {}


def get_credential(
    provider_type: str,
    credential_name: str,
    ct_base_url: str,
    api_key_env: str = "CT_API_KEY",
    org_id_env: str = "CT_ORG_ID",
) -> Callable[..., Any]:
    """FastAPI dependency factory that retrieves a decrypted credential payload.

    Usage::

        get_shopify_creds = get_credential("shopify", "production", ct_base_url="https://ct.example.com")

        @app.get("/sync")
        async def sync(creds: dict = Depends(get_shopify_creds)):
            ...
    """
    import os

    async def _get_cred() -> dict[str, str]:
        api_key = os.environ.get(api_key_env)
        if not api_key:
            raise RuntimeError(f"Environment variable {api_key_env} is required for vault access")
        org_id = os.environ.get(org_id_env)
        if not org_id:
            raise RuntimeError(f"Environment variable {org_id_env} is required for vault access")
        cache_key = (ct_base_url, api_key, org_id)

        if cache_key not in _vault_clients:
            from ct_auth.vault import VaultClient
            client = VaultClient(ct_base_url=ct_base_url, api_key=api_key, org_id=org_id)
            await client.__aenter__()
            _vault_clients[cache_key] = client

        vault = _vault_clients[cache_key]
        return await vault.get_payload(provider_type, credential_name)

    return _get_cred


async def close_vault_clients() -> None:
    """Close all cached VaultClient instances. Call on application shutdown."""
    for client in _vault_clients.values():
        try:
            await client.__aexit__(None, None, None)
        except Exception:
            pass
    _vault_clients.clear()

"""StatefulJWKSClient — holds exactly one JWKSClient at a time.

Design per PLAN-CT-004 D-016:
- Staging and local CT use distinct JWT signing keys.
- At any given moment, exactly ONE JWKSClient is live (pointing at the
  currently-active CT instance per the resolver).
- On state flip, the old cache is discarded; the new cache is populated
  lazily on demand. No cross-cache lookups, no cooldown amplification.
- Sync-path thread safety (A2-001) via ``threading.RLock``: both sync
  and async callers mutually exclude during the swap. The lock is held
  briefly (microseconds) around the ``_current`` swap — never across I/O.
- Callers that capture a local reference BEFORE the swap safely use that
  reference; the post-swap reference is only seen by callers that dereference
  ``self._current`` after the swap. This avoids stale-cache crashes.
"""

from __future__ import annotations

import asyncio
import logging
import threading
from typing import Any

from ct_auth.jwks import JWKSClient

_logger = logging.getLogger("ct_auth.stateful_jwks")


class StatefulJWKSClient:
    """Single-active JWKS cache that follows resolver state flips (AC-2.6–2.9)."""

    def __init__(self, resolver: Any, *, cache_ttl: int = 3600) -> None:
        self._resolver = resolver
        self._cache_ttl = cache_ttl
        self._lock = threading.RLock()
        initial_url = resolver.active_jwks_url()
        self._current: JWKSClient = JWKSClient(jwks_url=initial_url, cache_ttl=cache_ttl)
        resolver.subscribe(self._on_state_change)

    def _on_state_change(self, new_state: str) -> None:
        """Swap the underlying JWKSClient when resolver state flips (AC-2.7)."""
        new_url = self._resolver.active_jwks_url()
        with self._lock:
            if self._current.jwks_url == new_url:
                return
            _logger.warning(
                "ct_auth.stateful_jwks swap from=%s to=%s state=%s",
                self._current.jwks_url,
                new_url,
                new_state,
            )
            self._current = JWKSClient(jwks_url=new_url, cache_ttl=self._cache_ttl)

    async def get_public_key(self, kid: str | None = None) -> bytes:
        """Async path — captures a local reference to :attr:`_current` under the RLock.

        A-009: the RLock acquire is delegated to ``asyncio.to_thread`` per plan
        D-016 so that a worker thread holding the lock for a swap cannot block
        the event loop. The lock hold is microseconds; we only offload the
        acquire/release bracket, not any I/O.
        """
        def _capture_current() -> Any:
            with self._lock:
                return self._current

        client = await asyncio.to_thread(_capture_current)
        return await client.get_public_key(kid)

    def get_public_key_sync(self, kid: str | None = None) -> bytes:
        """Sync path with the same capture-before-use invariant."""
        with self._lock:
            client = self._current
        return client.get_public_key_sync(kid)

    def clear_cache(self) -> None:
        with self._lock:
            self._current.clear_cache()

    def close(self) -> None:
        """Unsubscribe from the resolver so the instance can be garbage-collected.

        A-203: `BFFRoutes.close()` calls this via its `hasattr(..., "close")`
        guard, ensuring state subscriber lifetime matches BFFRoutes lifetime.
        Safe to call multiple times.
        """
        if self._resolver is None:
            return
        unsubscribe = getattr(self._resolver, "unsubscribe", None)
        if callable(unsubscribe):
            try:
                unsubscribe(self._on_state_change)
            except Exception:  # noqa: BLE001
                _logger.debug("StatefulJWKSClient.close: unsubscribe raised", exc_info=True)
        self._resolver = None

"""Control Tower auth SDK for Python consumers."""

from ct_auth.jwks import JWKSClient
from ct_auth.permissions import (
    get_org_roles,
    has_app_permission,
    has_permission,
    has_role,
    is_platform_admin,
)
from ct_auth.validator import decode_token_unverified, validate_token

# B-040: only validation-pure names are in __all__. The lazy 0.8.0
# additions (resolver / notifiers / stateful_jwks / bff) are REACHABLE via
# ``from ct_auth import CTEndpointResolver`` (handled by __getattr__) and
# visible to ``dir()``/IDE/mypy via the _LAZY_NAMES set below and the
# __dir__() override, but they are NOT in ``__all__`` so
# ``from ct_auth import *`` does not eagerly trigger their imports and
# pull fastapi/httpx into validation-only consumers.
__all__ = [
    "JWKSClient",
    "decode_token_unverified",
    "get_org_roles",
    "has_app_permission",
    "has_permission",
    "has_role",
    "is_platform_admin",
    "validate_token",
]

# Lazy 0.8.0 additions. Listed here so `dir(ct_auth)` and IDE completion
# see them, but NOT in `__all__` so star-import stays lazy.
_LAZY_NAMES: frozenset[str] = frozenset({
    "CTBothDownError",
    "CTEndpointResolver",
    "FailoverEvent",
    "Notifier",
    "NoopNotifier",
    "CompositeNotifier",
    "EmailNotifier",
    "WebhookNotifier",
    "StatefulJWKSClient",
    "create_bff_routes",
    "BFFRoutes",
})


def __getattr__(name: str):  # noqa: ANN202
    """Lazy top-level re-exports for WP-SCC-2 0.8.0 types.

    A-209: ``CTBothDownError`` is importable from ``ct_auth`` directly so
    that ``bff.py`` can use a single top-level import instead of the
    factory-local import dance that obscured the closure-capture pattern.
    Other types are made available for convenience.
    """
    _resolver_symbols = {
        "CTBothDownError",
        "CTEndpointResolver",
        "FailoverEvent",
        "Notifier",
        "NoopNotifier",
        "CompositeNotifier",
    }
    if name in _resolver_symbols:
        from ct_auth import resolver as _r

        return getattr(_r, name)
    if name in ("EmailNotifier", "WebhookNotifier"):
        from ct_auth import notifiers as _n

        return getattr(_n, name)
    if name == "StatefulJWKSClient":
        from ct_auth.stateful_jwks import StatefulJWKSClient as _C

        return _C
    if name in ("create_bff_routes", "BFFRoutes"):
        from ct_auth import bff as _b

        return getattr(_b, name)
    raise AttributeError(f"module 'ct_auth' has no attribute {name!r}")


def __dir__() -> list[str]:
    """Include lazy-exported names in ``dir(ct_auth)`` (A-302) without
    putting them in ``__all__`` (which would eagerly trigger __getattr__
    during ``from ct_auth import *``; B-040)."""
    return sorted(set(__all__) | _LAZY_NAMES | set(globals().keys()))

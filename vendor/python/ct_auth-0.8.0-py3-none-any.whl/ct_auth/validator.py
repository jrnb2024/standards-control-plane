"""JWT validation for Control Tower tokens."""

from __future__ import annotations

from typing import Any

import jwt


def validate_token(
    token: str,
    public_key: bytes,
    audience: str | None = None,
) -> dict[str, Any]:
    """Verify an RS256-signed JWT from Control Tower.

    Checks:
    - RS256 signature validity
    - Issuer is ``"control-tower"``
    - Token is not expired
    - Audience matches (if ``audience`` is provided)

    Args:
        token: The raw JWT string.
        public_key: PEM-encoded RSA public key bytes.
        audience: Expected audience value (e.g. your app ID). If None,
            audience validation is skipped for backward compatibility.

    Returns:
        Decoded claims dict.

    Raises:
        jwt.ExpiredSignatureError: If the token has expired.
        jwt.InvalidIssuerError: If the issuer is not ``"control-tower"``.
        jwt.InvalidAudienceError: If the audience does not match.
        jwt.InvalidTokenError: For any other validation failure.
    """
    options: dict[str, bool] = {}
    if audience is None:
        options["verify_aud"] = False

    return jwt.decode(
        token,
        public_key,
        algorithms=["RS256"],
        issuer="control-tower",
        audience=audience,
        options=options,
    )


def decode_token_unverified(token: str) -> dict[str, Any]:
    """Decode a JWT without verifying the signature.

    Useful for extracting the ``kid`` from the header before fetching
    the matching public key from JWKS.

    Args:
        token: The raw JWT string.

    Returns:
        A dict with ``"header"`` and ``"payload"`` keys.
    """
    header = jwt.get_unverified_header(token)
    payload = jwt.decode(token, options={"verify_signature": False})
    return {"header": header, "payload": payload}

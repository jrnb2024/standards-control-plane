"""Vault client for retrieving integration credentials from Control Tower.

Usage::

    from ct_auth.vault import VaultClient

    async with VaultClient(
        ct_base_url="https://ct.example.com",
        api_key="ct_sa_...",
        org_id="org-123",
    ) as vault:
        payload = await vault.get_payload("shopify", "production-store")
        # payload = {"client_id": "...", "client_secret": "..."}
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass
from typing import Any, Protocol, runtime_checkable
from urllib.parse import quote

from ct_auth.s2s import ServiceAccountClient

_logger = logging.getLogger("ct_auth.vault")

_MAX_CACHE_TTL = 600  # Hard cap on cache TTL (seconds)


@dataclass
class CredentialInfo:
    """Credential metadata (and optionally payload) returned by VaultClient."""
    id: str
    org_id: str
    provider_type: str
    credential_name: str
    auth_type: str
    metadata: dict[str, Any] | None = None
    is_active: bool = True
    last_used_at: str | None = None
    expires_at: str | None = None
    created_at: str = ""
    updated_at: str = ""
    payload: dict[str, str] | None = None


@runtime_checkable
class TokenAcquirer(Protocol):
    """Protocol for OAuth token acquisition."""
    async def acquire_token(
        self, credential_payload: dict[str, str], metadata: dict[str, Any] | None,
    ) -> Any:
        """Must return an object with .access_token attribute or a dict with 'access_token' key."""
        ...


class VaultClient:
    """Client for the Control Tower credential vault.

    Retrieves credentials via S2S authentication. Metadata is cached;
    decrypted payloads are NEVER cached (security).
    """

    def __init__(
        self,
        ct_base_url: str,
        api_key: str,
        org_id: str,
        cache_ttl: float = 300.0,
        max_cache_size: int = 200,
        timeout: float = 30.0,
    ) -> None:
        self._base_url = ct_base_url.rstrip("/")
        self._api_key = api_key
        self._org_id = org_id
        self._cache_ttl = min(cache_ttl, _MAX_CACHE_TTL)
        self._max_cache_size = max_cache_size
        self._client = ServiceAccountClient(
            ct_base_url=ct_base_url,
            api_key=api_key,
            org_id=org_id,
            timeout=timeout,
        )
        self._cache: dict[tuple[str, str], tuple[float, CredentialInfo]] = {}

    async def __aenter__(self) -> VaultClient:
        await self._client.__aenter__()
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self._client.__aexit__(*args)

    async def get(self, provider_type: str, credential_name: str) -> CredentialInfo:
        """Get credential metadata (cached). Payload is NOT included."""
        cache_key = (provider_type, credential_name)
        credential_path = (
            f"/api/v1/orgs/{quote(self._org_id, safe='')}/credentials/by-name/"
            f"{quote(provider_type, safe='')}/{quote(credential_name, safe='')}"
        )

        # Check cache
        if cache_key in self._cache:
            ts, info = self._cache[cache_key]
            if time.monotonic() - ts < self._cache_ttl:
                return info

        # Fetch from CT
        resp = await self._client.request(
            "GET",
            credential_path,
        )
        resp.raise_for_status()
        data = resp.json()

        info = _parse_credential_info(data)
        # Strip payload — get() returns metadata only
        info.payload = None

        self._cache[cache_key] = (time.monotonic(), info)
        self._evict_if_needed()

        return info

    async def get_payload(self, provider_type: str, credential_name: str) -> dict[str, str]:
        """Get decrypted credential payload. NOT cached (security)."""
        credential_path = (
            f"/api/v1/orgs/{quote(self._org_id, safe='')}/credentials/by-name/"
            f"{quote(provider_type, safe='')}/{quote(credential_name, safe='')}"
        )
        resp = await self._client.request(
            "GET",
            credential_path,
        )
        resp.raise_for_status()
        data = resp.json()
        payload = data.get("payload")
        if payload is None:
            raise ValueError(
                f"No payload returned for {provider_type}/{credential_name}. "
                "Check that the service account has the correct credential_type_grant."
            )
        return payload

    async def get_access_token(
        self, provider_type: str, credential_name: str, acquirer: TokenAcquirer,
    ) -> str:
        """Get an OAuth access token via credential payload + acquirer."""
        # Ensure metadata is cached before fetching payload
        info = await self.get(provider_type, credential_name)
        payload = await self.get_payload(provider_type, credential_name)
        result = await acquirer.acquire_token(payload, info.metadata)
        if isinstance(result, dict):
            return result["access_token"]
        return result.access_token

    async def store(
        self,
        provider_type: str,
        credential_name: str,
        auth_type: str,
        payload: dict[str, str],
        metadata: dict[str, Any] | None = None,
    ) -> CredentialInfo:
        """Create a new credential in the vault."""
        body: dict[str, Any] = {
            "provider_type": provider_type,
            "credential_name": credential_name,
            "auth_type": auth_type,
            "payload": payload,
        }
        if metadata:
            body["metadata"] = metadata
        resp = await self._client.request(
            "POST",
            f"/api/v1/orgs/{self._org_id}/credentials",
            json=body,
        )
        resp.raise_for_status()
        return _parse_credential_info(resp.json())

    async def rotate(
        self, provider_type: str, credential_name: str, new_payload: dict[str, str],
    ) -> dict[str, str]:
        """Rotate credential payload. Returns the new payload. Invalidates cache."""
        # Resolve ID via cached get
        info = await self.get(provider_type, credential_name)
        resp = await self._client.request(
            "PUT",
            f"/api/v1/orgs/{self._org_id}/credentials/{info.id}/payload",
            json={"payload": new_payload},
        )
        resp.raise_for_status()
        # Invalidate cache
        self._cache.pop((provider_type, credential_name), None)
        return resp.json().get("payload", new_payload)

    async def deactivate(self, provider_type: str, credential_name: str) -> None:
        """Deactivate (soft-delete) a credential."""
        info = await self.get(provider_type, credential_name)
        resp = await self._client.request(
            "DELETE",
            f"/api/v1/orgs/{self._org_id}/credentials/{info.id}",
        )
        resp.raise_for_status()
        self._cache.pop((provider_type, credential_name), None)

    def _evict_if_needed(self) -> None:
        """Evict oldest cache entries if over max size."""
        while len(self._cache) > self._max_cache_size:
            oldest_key = min(self._cache, key=lambda k: self._cache[k][0])
            del self._cache[oldest_key]


def _parse_credential_info(data: dict[str, Any]) -> CredentialInfo:
    """Parse API response dict into CredentialInfo."""
    return CredentialInfo(
        id=data["id"],
        org_id=data["org_id"],
        provider_type=data["provider_type"],
        credential_name=data["credential_name"],
        auth_type=data["auth_type"],
        metadata=data.get("metadata"),
        is_active=data.get("is_active", True),
        last_used_at=data.get("last_used_at"),
        expires_at=data.get("expires_at"),
        created_at=data.get("created_at", ""),
        updated_at=data.get("updated_at", ""),
        payload=data.get("payload"),
    )

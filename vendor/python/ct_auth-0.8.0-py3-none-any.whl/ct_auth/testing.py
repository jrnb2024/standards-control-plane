"""Test helpers for S2S authentication in consumer services.

Usage::

    from ct_auth.testing import InMemoryServiceAccountClient, MockRequireServiceScope

    # Replace ServiceAccountClient in tests
    client = InMemoryServiceAccountClient(
        sa_info={"id": "test-sa", "org_id": "org1", "scopes": ["vault:creds:read"]},
    )

    # Replace RequireServiceScope in FastAPI dependency overrides
    app.dependency_overrides[require_vault_read] = MockRequireServiceScope(
        scopes=["vault:creds:read"],
        sa_info={"id": "test-sa", "org_id": "org1"},
    )
"""

from __future__ import annotations

import hashlib
import time
import uuid
from datetime import datetime, timezone
from typing import Any

import httpx


def make_sample_claims(**overrides: Any) -> dict[str, Any]:
    """Return a complete Control Tower JWT claims dict for testing.

    All fields are overridable via keyword arguments. Returns a dict matching
    the full CT JWT claims structure (CT-DOC-002):

    - ``sub`` (str): User ID, e.g. ``"user-123"``
    - ``email`` (str): User email, e.g. ``"user@example.com"``
    - ``display_name`` (str): User display name, e.g. ``"Test User"``
    - ``org_ids`` (list[str]): Organisation IDs the user belongs to
    - ``roles`` (list[str]): Flat/global roles
    - ``org_roles`` (dict[str, list[str]]): Per-org role mappings
    - ``app_permissions`` (dict[str, list[str]]): Per-app permission grants
    - ``teams`` (list[str]): Team memberships
    - ``iss`` (str): Issuer, always ``"control-tower"``
    - ``aud`` (list[str]): Audience list (app IDs this token is valid for)
    - ``iat`` (int | float): Issued-at timestamp (epoch seconds)
    - ``exp`` (int | float): Expiry timestamp (epoch seconds, default iat + 900)
    - ``jti`` (str): Unique token ID (UUID hex)

    Usage::

        from ct_auth.testing import make_sample_claims

        claims = make_sample_claims()  # all defaults
        claims = make_sample_claims(sub="admin-1", roles=["admin"])
    """
    now = int(time.time())  # RFC 7519: NumericDate is integer
    claims: dict[str, Any] = {
        "sub": "user-123",
        "email": "user@example.com",
        "display_name": "Test User",
        "org_ids": ["org-1"],
        "roles": ["editor"],
        "org_roles": {"org-1": ["editor"]},
        "app_permissions": {"fla": ["*"]},
        "teams": [],
        "iss": "control-tower",
        "aud": ["control-tower", "fla", "returns"],
        "iat": now,
        "exp": now + 900,
        "jti": uuid.uuid4().hex,
    }
    claims.update(overrides)
    return claims


class InMemoryServiceAccountClient:
    """Drop-in replacement for ServiceAccountClient that operates in-memory.

    All requests are recorded in ``self.requests`` for test assertions.
    Note: default scopes are empty — configure explicitly for your tests.
    """

    def __init__(
        self,
        sa_info: dict[str, Any] | None = None,
        org_id: str | None = None,
    ) -> None:
        self._sa_info = sa_info or {
            "id": "test-sa",
            "org_id": org_id or "test-org",
            "name": "test-service-account",
            "scopes": [],
            "is_active": True,
            "last_used_at": None,
            "expires_at": None,
            "created_at": datetime.now(timezone.utc).isoformat(),
        }
        self._org_id = org_id or self._sa_info.get("org_id", "test-org")
        self.requests: list[dict[str, Any]] = []
        self._responses: dict[str, httpx.Response] = {}

    async def __aenter__(self) -> InMemoryServiceAccountClient:
        return self

    async def __aexit__(self, *args: Any) -> None:
        pass

    async def whoami(self) -> dict[str, Any]:
        """Return the configured SA info."""
        self.requests.append({"method": "GET", "path": "/api/v1/service-accounts/me"})
        return self._sa_info

    async def request(
        self,
        method: str,
        path: str,
        **kwargs: Any,
    ) -> httpx.Response:
        """Record the request and return a configured or default 200 response."""
        self.requests.append({"method": method, "path": path, **kwargs})
        key = f"{method} {path}"
        if key in self._responses:
            return self._responses[key]
        # Default: 200 with empty JSON
        return httpx.Response(status_code=200, json={})

    def set_response(self, method: str, path: str, response: httpx.Response) -> None:
        """Pre-configure a response for a specific method+path."""
        self._responses[f"{method} {path}"] = response

    @property
    def org_id(self) -> str | None:
        return self._org_id

    @property
    def sa_info(self) -> dict[str, Any] | None:
        return self._sa_info

    @property
    def api_key_hash(self) -> str:
        """Deterministic hash for cache keying in tests."""
        return hashlib.sha256(b"test-api-key").hexdigest()


class MockRequireServiceScope:
    """Drop-in replacement for RequireServiceScope in FastAPI dependency overrides.

    Always succeeds if the configured scopes match, or if the scopes contain ``*``.
    """

    def __init__(
        self,
        scopes: list[str] | None = None,
        sa_info: dict[str, Any] | None = None,
    ) -> None:
        self._sa_info = sa_info or {
            "id": "mock-sa",
            "org_id": "mock-org",
            "name": "mock-service-account",
            "scopes": scopes or ["*"],
            "is_active": True,
            "last_used_at": None,
            "expires_at": None,
            "created_at": datetime.now(timezone.utc).isoformat(),
        }
        if scopes:
            self._sa_info["scopes"] = scopes

    async def __call__(self, request: Any = None, **kwargs: Any) -> dict[str, Any]:
        """Return the configured SA info (always passes).

        Accepts ``request`` parameter to match the real RequireServiceScope signature.
        """
        return self._sa_info


class InMemoryVault:
    """Drop-in replacement for VaultClient in tests.

    Provides full lifecycle: store, get, get_payload, rotate, deactivate.
    Tracks all operations in ``self.operations`` for test assertions.
    Enforces org isolation.
    """

    def __init__(self, org_id: str = "test-org") -> None:
        self._org_id = org_id
        # Internal store: (org_id, provider_type, name) -> credential dict
        self._store: dict[tuple[str, str, str], dict[str, Any]] = {}
        self.operations: list[dict[str, Any]] = []

    async def __aenter__(self) -> "InMemoryVault":
        return self

    async def __aexit__(self, *args: Any) -> None:
        pass

    def _key(self, provider_type: str, name: str) -> tuple[str, str, str]:
        return (self._org_id, provider_type, name)

    async def store(
        self,
        provider_type: str,
        credential_name: str,
        auth_type: str,
        payload: dict[str, str],
        metadata: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Store a credential. Returns metadata dict."""
        key = self._key(provider_type, credential_name)
        cred = {
            "id": hashlib.sha256(f"{key}".encode()).hexdigest()[:32],
            "org_id": self._org_id,
            "provider_type": provider_type,
            "credential_name": credential_name,
            "auth_type": auth_type,
            "payload": dict(payload),
            "metadata": metadata,
            "is_active": True,
            "state": "active",
            "last_used_at": None,
            "expires_at": None,
            "created_at": datetime.now(timezone.utc).isoformat(),
            "updated_at": datetime.now(timezone.utc).isoformat(),
        }
        self._store[key] = cred
        self.operations.append({"op": "store", "provider_type": provider_type, "name": credential_name})
        return {k: v for k, v in cred.items() if k != "payload"}

    async def get(self, provider_type: str, credential_name: str) -> dict[str, Any]:
        """Get credential metadata (no payload)."""
        key = self._key(provider_type, credential_name)
        cred = self._store.get(key)
        if cred is None or not cred["is_active"]:
            raise KeyError(f"Credential not found: {provider_type}/{credential_name}")
        self.operations.append({"op": "get", "provider_type": provider_type, "name": credential_name})
        return {k: v for k, v in cred.items() if k != "payload"}

    async def get_payload(self, provider_type: str, credential_name: str) -> dict[str, str]:
        """Get decrypted credential payload."""
        key = self._key(provider_type, credential_name)
        cred = self._store.get(key)
        if cred is None or not cred["is_active"]:
            raise KeyError(f"Credential not found: {provider_type}/{credential_name}")
        self.operations.append({"op": "get_payload", "provider_type": provider_type, "name": credential_name})
        return dict(cred["payload"])

    async def rotate(
        self, provider_type: str, credential_name: str, new_payload: dict[str, str],
    ) -> dict[str, str]:
        """Rotate credential payload."""
        key = self._key(provider_type, credential_name)
        cred = self._store.get(key)
        if cred is None or not cred["is_active"]:
            raise KeyError(f"Credential not found: {provider_type}/{credential_name}")
        cred["payload"] = dict(new_payload)
        cred["state"] = "rotated"
        cred["updated_at"] = datetime.now(timezone.utc).isoformat()
        self.operations.append({"op": "rotate", "provider_type": provider_type, "name": credential_name})
        return dict(new_payload)

    async def deactivate(self, provider_type: str, credential_name: str) -> None:
        """Deactivate (soft-delete) a credential."""
        key = self._key(provider_type, credential_name)
        cred = self._store.get(key)
        if cred is None:
            raise KeyError(f"Credential not found: {provider_type}/{credential_name}")
        cred["is_active"] = False
        cred["state"] = "deactivated"
        self.operations.append({"op": "deactivate", "provider_type": provider_type, "name": credential_name})

    @property
    def org_id(self) -> str:
        return self._org_id


class InMemoryCTServer:
    """Mock Control Tower server for BFF route testing.

    Uses ``httpx.MockTransport`` to simulate CT's login, OAuth token exchange,
    and refresh endpoints.
    Supports configurable failure modes via boolean flags.

    Usage::

        server = InMemoryCTServer()
        bff = create_bff_routes(
            ct_base_url="http://localhost:8000",
            http_client=server.client,
        )

        # Simulate failures
        server.fail_login = True    # 401 on login
        server.fail_refresh = True         # 401 on refresh
        server.fail_token_exchange = True  # 400 on auth code exchange
        server.rate_limited = True         # 429 on all requests
        server.server_error = True         # 500 on all requests
    """

    def __init__(self) -> None:
        self.fail_login: bool = False
        self.fail_refresh: bool = False
        self.fail_token_exchange: bool = False
        self.rate_limited: bool = False
        self.server_error: bool = False
        self._token_counter: int = 0
        self.last_login_headers: dict[str, str] | None = None
        self.last_refresh_headers: dict[str, str] | None = None
        self.last_token_exchange_body: dict[str, Any] | None = None
        self.last_token_exchange_headers: dict[str, str] | None = None
        self.client: httpx.AsyncClient = httpx.AsyncClient(
            transport=httpx.MockTransport(self._handler),
        )

    def _handler(self, request: httpx.Request) -> httpx.Response:
        """Route handler for mock transport."""
        path = request.url.path

        # Global failure modes checked first
        if self.rate_limited:
            return httpx.Response(
                status_code=429,
                json={"error": "rate_limited", "message": "Too many requests"},
            )
        if self.server_error:
            return httpx.Response(
                status_code=500,
                json={"error": "internal_error", "message": "Internal server error"},
            )

        if path == "/api/v1/auth/login" and request.method == "POST":
            return self._handle_login(request)
        if path == "/api/v1/auth/token" and request.method == "POST":
            return self._handle_token_exchange(request)
        if path == "/api/v1/auth/refresh" and request.method == "POST":
            return self._handle_refresh(request)

        return httpx.Response(status_code=404, json={"error": "not_found"})

    def _handle_login(self, request: httpx.Request) -> httpx.Response:
        self.last_login_headers = dict(request.headers)
        if self.fail_login:
            return httpx.Response(
                status_code=401,
                json={"error": "invalid_credentials", "message": "Invalid email or password"},
            )

        import json as _json

        body = _json.loads(request.content)
        email = body.get("email", "unknown@example.com")
        self._token_counter += 1
        return httpx.Response(
            status_code=200,
            json={
                "access_token": f"fake-access-token-{self._token_counter}",
                "refresh_token": f"fake-refresh-token-{self._token_counter}",
                "token_type": "bearer",
                "user": {
                    "id": "user-001",
                    "email": email,
                    "name": "Test User",
                },
            },
        )

    def _handle_refresh(self, request: httpx.Request) -> httpx.Response:
        self.last_refresh_headers = dict(request.headers)
        if self.fail_refresh:
            return httpx.Response(
                status_code=401,
                json={"error": "invalid_refresh_token", "message": "Refresh token expired or invalid"},
            )

        self._token_counter += 1
        return httpx.Response(
            status_code=200,
            json={
                "access_token": f"fake-access-token-{self._token_counter}",
                "refresh_token": f"fake-refresh-token-{self._token_counter}",
                "token_type": "bearer",
                "user": {
                    "id": "user-001",
                    "email": "user@example.com",
                    "name": "Test User",
                },
                },
            )

    def _handle_token_exchange(self, request: httpx.Request) -> httpx.Response:
        import json as _json

        body = _json.loads(request.content)
        self.last_token_exchange_body = body
        self.last_token_exchange_headers = dict(request.headers)

        if self.fail_token_exchange:
            return httpx.Response(
                status_code=400,
                json={
                    "detail": {
                        "error": "invalid_grant",
                        "message": "Authorization code is invalid or has already been used",
                    }
                },
            )

        self._token_counter += 1
        return httpx.Response(
            status_code=200,
            json={
                "access_token": f"fake-access-token-{self._token_counter}",
                "refresh_token": f"fake-refresh-token-{self._token_counter}",
                "token_type": "bearer",
            },
        )
